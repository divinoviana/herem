# Documentação do Portal de Filosofia

## Introdução

Este documento fornece instruções detalhadas sobre como utilizar e manter o Portal de Filosofia, um site desenvolvido para compartilhar material didático de filosofia com alunos do ensino médio da educação básica pública do Brasil.

O Portal de Filosofia foi construído utilizando tecnologias modernas como Next.js e Tailwind CSS, garantindo uma experiência de usuário atraente, interativa e responsiva em diferentes dispositivos (computadores, tablets e smartphones).

## Estrutura do Site

O Portal de Filosofia está organizado nas seguintes seções principais:

1. **Página Inicial**: Apresentação do portal e acesso rápido às principais seções
2. **Áreas Temáticas**: Conteúdos organizados por períodos e correntes filosóficas
3. **Recursos Didáticos**: Materiais de apoio como textos, HQs, mapas mentais e resumos
4. **Atividades Interativas**: Quizzes, jogos, fóruns e chats para engajamento dos alunos
5. **Sobre**: Informações sobre o portal, missão, valores e equipe

Além disso, há uma seção especial dedicada ao filósofo Spinoza, conforme solicitado.

## Como Adicionar Novos Conteúdos

### Princípios Gerais

Para manter a padronização visual e estrutural do site ao adicionar novos conteúdos, siga estas diretrizes:

1. Utilize os templates existentes como base para novas páginas
2. Mantenha a consistência visual (cores, fontes, espaçamentos)
3. Garanta que todas as páginas sejam responsivas
4. Inclua elementos interativos para engajar os alunos

### Adicionando Conteúdo em Áreas Temáticas

Para adicionar uma nova página em Áreas Temáticas:

1. Navegue até a pasta `/src/app/areas-tematicas/`
2. Crie uma nova pasta com o nome da área temática (use slugs: letras minúsculas, sem acentos, separadas por hífen)
3. Dentro desta pasta, crie um arquivo `page.tsx` baseado no template existente
4. Personalize o conteúdo mantendo a estrutura de componentes

**Exemplo**: Para adicionar uma página sobre "Filosofia Contemporânea":

```tsx
// Arquivo: /src/app/areas-tematicas/filosofia-contemporanea/page.tsx

import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";

export default function FilosofiaContemporaneaPage() {
  return (
    <MainLayout>
      <section className="filosofia-hero bg-primary">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/80 to-secondary/80 opacity-90"></div>
        <div className="container relative z-10 mx-auto px-4 py-16 text-center">
          <h1 className="mb-6 text-4xl font-bold md:text-5xl lg:text-6xl">
            Filosofia Contemporânea
          </h1>
          <p className="mx-auto mb-8 max-w-3xl text-lg md:text-xl">
            Explore as correntes filosóficas dos séculos XIX, XX e XXI.
          </p>
        </div>
      </section>

      <!-- Conteúdo da página -->
      
    </MainLayout>
  );
}
```

### Adicionando Recursos Didáticos

Para adicionar um novo recurso didático:

1. Navegue até a pasta `/src/app/recursos-didaticos/conteudo/`
2. Crie uma nova pasta com o nome do recurso (use slugs)
3. Dentro desta pasta, crie um arquivo `page.tsx` baseado no template existente
4. Personalize o conteúdo mantendo a estrutura de componentes

**Exemplo**: Para adicionar um mapa mental sobre "Ética de Spinoza":

```tsx
// Arquivo: /src/app/recursos-didaticos/conteudo/mapa-etica-spinoza/page.tsx

import { MainLayout } from "@/components/layout/main-layout";
import Image from "next/image";

export default function MapaEticaSpinozaPage() {
  return (
    <MainLayout>
      <section className="filosofia-hero bg-accent">
        <div className="absolute inset-0 bg-gradient-to-r from-accent/80 to-primary/80 opacity-90"></div>
        <div className="container relative z-10 mx-auto px-4 py-16 text-center">
          <h1 className="mb-6 text-4xl font-bold md:text-5xl lg:text-6xl">
            Mapa Mental: Ética de Spinoza
          </h1>
          <p className="mx-auto mb-8 max-w-3xl text-lg md:text-xl">
            Visualização dos conceitos e relações na obra-prima de Spinoza.
          </p>
        </div>
      </section>

      <section className="filosofia-section">
        <div className="filosofia-container">
          <!-- Conteúdo do mapa mental -->
          <div className="mx-auto max-w-4xl">
            <Image 
              src="/images/mapa-etica-spinoza.jpg" 
              alt="Mapa Mental da Ética de Spinoza" 
              width={1200} 
              height={800} 
              className="rounded-lg shadow-lg"
            />
            
            <!-- Explicações e legendas -->
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
```

### Adicionando Atividades Interativas

Para adicionar uma nova atividade interativa:

1. Navegue até a pasta `/src/app/atividades-interativas/`
2. Crie uma nova pasta com o nome da atividade (use slugs)
3. Dentro desta pasta, crie um arquivo `page.tsx` baseado no template existente
4. Personalize o conteúdo mantendo a estrutura de componentes

**Exemplo**: Para adicionar um novo quiz sobre "Filosofia Antiga":

```tsx
// Arquivo: /src/app/atividades-interativas/quizzes/filosofia-antiga/page.tsx

import { MainLayout } from "@/components/layout/main-layout";
import { QuizComponent } from "@/components/interativos/quiz";

export default function QuizFilosofiaAntigaPage() {
  // Dados do quiz
  const quizData = {
    title: "Quiz: Filosofia Antiga",
    description: "Teste seus conhecimentos sobre os filósofos da Grécia Antiga",
    questions: [
      {
        question: "Quem foi o mestre de Platão?",
        options: ["Aristóteles", "Sócrates", "Parmênides", "Heráclito"],
        correctAnswer: 1
      },
      // Mais perguntas...
    ]
  };

  return (
    <MainLayout>
      <section className="filosofia-hero bg-secondary">
        <div className="absolute inset-0 bg-gradient-to-r from-secondary/80 to-accent/80 opacity-90"></div>
        <div className="container relative z-10 mx-auto px-4 py-16 text-center">
          <h1 className="mb-6 text-4xl font-bold md:text-5xl lg:text-6xl">
            {quizData.title}
          </h1>
          <p className="mx-auto mb-8 max-w-3xl text-lg md:text-xl">
            {quizData.description}
          </p>
        </div>
      </section>

      <section className="filosofia-section">
        <div className="filosofia-container">
          <QuizComponent quizData={quizData} />
        </div>
      </section>
    </MainLayout>
  );
}
```

### Atualizando a Seção Especial sobre Spinoza

Para atualizar ou expandir a seção dedicada a Spinoza:

1. Navegue até a pasta `/src/app/areas-tematicas/filosofia-moderna/spinoza/`
2. Edite o arquivo `page.tsx` para atualizar o conteúdo principal
3. Para adicionar subpáginas específicas (como obras, conceitos), crie pastas adicionais dentro deste diretório

**Exemplo**: Para adicionar uma página sobre a obra "Tratado Teológico-Político":

```tsx
// Arquivo: /src/app/areas-tematicas/filosofia-moderna/spinoza/tratado-teologico-politico/page.tsx

import { MainLayout } from "@/components/layout/main-layout";
// Outros imports necessários

export default function TratadoTeologicoPoliticoPage() {
  return (
    <MainLayout>
      <section className="filosofia-hero bg-primary">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/80 to-secondary/80 opacity-90"></div>
        <div className="container relative z-10 mx-auto px-4 py-16 text-center">
          <h1 className="mb-6 text-4xl font-bold md:text-5xl lg:text-6xl">
            Tratado Teológico-Político
          </h1>
          <p className="mx-auto mb-8 max-w-3xl text-lg md:text-xl">
            Análise da obra política de Spinoza e sua defesa da liberdade de pensamento.
          </p>
        </div>
      </section>

      <!-- Conteúdo sobre o Tratado Teológico-Político -->
      
    </MainLayout>
  );
}
```

## Gerenciando Componentes Reutilizáveis

O site utiliza componentes reutilizáveis para manter a consistência visual e facilitar a manutenção. Estes componentes estão localizados na pasta `/src/components/`.

### Principais Componentes

1. **Layout**: Componentes de estrutura como cabeçalho, rodapé e layout principal
   - `/src/components/layout/header.tsx`
   - `/src/components/layout/footer.tsx`
   - `/src/components/layout/main-layout.tsx`

2. **UI**: Componentes de interface como botões, cards e formulários
   - `/src/components/ui/button.tsx`
   - `/src/components/ui/card.tsx`
   - etc.

3. **Filosofia**: Componentes específicos para conteúdo filosófico
   - `/src/components/filosofia/filosofo-card.tsx`
   - `/src/components/filosofia/timeline.tsx`
   - etc.

4. **Interativos**: Componentes para atividades interativas
   - `/src/components/interativos/quiz.tsx`
   - `/src/components/interativos/forum.tsx`
   - etc.

### Modificando Componentes Existentes

Para modificar um componente existente:

1. Navegue até o arquivo do componente na pasta `/src/components/`
2. Faça as alterações necessárias, mantendo a estrutura e propriedades do componente
3. Teste as alterações para garantir que não afetam negativamente outras partes do site

**Exemplo**: Modificando o componente de cabeçalho para adicionar um novo item de menu:

```tsx
// Arquivo: /src/components/layout/header.tsx

// Código existente...

const menuItems = [
  { label: "Início", href: "/" },
  { label: "Áreas Temáticas", href: "/areas-tematicas" },
  { label: "Recursos Didáticos", href: "/recursos-didaticos" },
  { label: "Atividades Interativas", href: "/atividades-interativas" },
  { label: "Eventos", href: "/eventos" }, // Novo item adicionado
  { label: "Sobre", href: "/sobre" },
];

// Resto do código...
```

### Criando Novos Componentes

Para criar um novo componente reutilizável:

1. Identifique a categoria apropriada na pasta `/src/components/`
2. Crie um novo arquivo com nome descritivo e extensão `.tsx`
3. Implemente o componente seguindo o padrão dos componentes existentes
4. Importe e utilize o novo componente nas páginas onde for necessário

**Exemplo**: Criando um componente para exibir citações filosóficas:

```tsx
// Arquivo: /src/components/filosofia/citacao.tsx

import React from "react";

interface CitacaoProps {
  texto: string;
  autor: string;
  obra?: string;
  ano?: string;
}

export function Citacao({ texto, autor, obra, ano }: CitacaoProps) {
  return (
    <div className="my-8 border-l-4 border-primary pl-4">
      <blockquote className="italic text-lg text-muted-foreground">"{texto}"</blockquote>
      <div className="mt-2 font-semibold">
        {autor}
        {obra && <span className="font-normal">, {obra}</span>}
        {ano && <span className="font-normal"> ({ano})</span>}
      </div>
    </div>
  );
}
```

## Gerenciando Estilos e Temas

O site utiliza Tailwind CSS para estilização, com uma paleta de cores personalizada definida no arquivo `/tailwind.config.ts`.

### Modificando a Paleta de Cores

Para modificar a paleta de cores do site:

1. Abra o arquivo `/tailwind.config.ts`
2. Localize a seção `theme.extend.colors`
3. Modifique os valores das cores conforme necessário

**Exemplo**:

```typescript
// Arquivo: /tailwind.config.ts

// Código existente...

theme: {
  extend: {
    colors: {
      primary: {
        DEFAULT: "#1a237e", // Azul escuro (modificado)
        foreground: "#ffffff",
      },
      secondary: {
        DEFAULT: "#7b1fa2", // Roxo (modificado)
        foreground: "#ffffff",
      },
      // Outras cores...
    },
    // Outras extensões...
  },
},

// Resto do código...
```

### Adicionando Estilos Globais

Para adicionar ou modificar estilos globais:

1. Abra o arquivo `/src/app/globals.css`
2. Adicione ou modifique as classes CSS conforme necessário

**Exemplo**:

```css
/* Arquivo: /src/app/globals.css */

/* Código existente... */

/* Classes personalizadas para seções filosóficas */
.filosofia-section {
  @apply py-16;
}

.filosofia-container {
  @apply container mx-auto px-4;
}

.filosofia-heading {
  @apply text-3xl font-bold mb-8 md:text-4xl;
}

.filosofia-subheading {
  @apply text-2xl font-bold mb-4;
}

.filosofia-card {
  @apply transition-all duration-300 hover:shadow-lg;
}

/* Novas classes adicionadas */
.filosofia-quote {
  @apply my-8 border-l-4 border-primary pl-4 italic;
}

.filosofia-highlight {
  @apply bg-accent/20 px-2 py-1 rounded;
}

/* Resto do código... */
```

## Adicionando Imagens e Mídia

### Estrutura de Arquivos de Mídia

Os arquivos de mídia (imagens, vídeos, documentos) devem ser organizados na pasta `/public/`:

- `/public/images/`: Para imagens
  - `/public/images/filosofos/`: Fotos de filósofos
  - `/public/images/obras/`: Imagens de obras
  - `/public/images/conceitos/`: Ilustrações de conceitos
- `/public/docs/`: Para documentos (PDFs, etc.)
- `/public/videos/`: Para arquivos de vídeo

### Adicionando Novas Imagens

Para adicionar novas imagens ao site:

1. Coloque o arquivo de imagem na pasta apropriada dentro de `/public/images/`
2. Utilize o componente `Image` do Next.js para exibir a imagem com otimização automática

**Exemplo**:

```tsx
import Image from "next/image";

// Em um componente ou página...
<Image 
  src="/images/filosofos/spinoza.jpg" 
  alt="Baruch Spinoza" 
  width={400} 
  height={600} 
  className="rounded-lg shadow-md"
/>
```

### Adicionando Vídeos

Para incorporar vídeos do YouTube ou outras plataformas:

```tsx
// Em um componente ou página...
<div className="aspect-video w-full overflow-hidden rounded-lg">
  <iframe
    src="https://www.youtube.com/embed/VIDEO_ID"
    title="Título do Vídeo"
    allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
    allowFullScreen
    className="h-full w-full"
  ></iframe>
</div>
```

Para vídeos hospedados localmente:

```tsx
// Em um componente ou página...
<video
  controls
  className="w-full rounded-lg"
  poster="/images/thumbnails/video-thumbnail.jpg"
>
  <source src="/videos/aula-spinoza.mp4" type="video/mp4" />
  Seu navegador não suporta o elemento de vídeo.
</video>
```

## Publicando o Site na Internet

### Preparação para Publicação

Antes de publicar o site, certifique-se de:

1. Testar todas as páginas e funcionalidades
2. Verificar a responsividade em diferentes dispositivos
3. Otimizar imagens e outros recursos para carregamento rápido
4. Verificar links quebrados ou conteúdo incompleto

### Opções de Hospedagem

O site pode ser hospedado em várias plataformas:

1. **Vercel** (recomendado para sites Next.js)
   - Crie uma conta em [vercel.com](https://vercel.com)
   - Conecte ao repositório do GitHub (se estiver usando)
   - Ou faça deploy diretamente via CLI da Vercel

2. **Netlify**
   - Crie uma conta em [netlify.com](https://netlify.com)
   - Faça upload da pasta de build ou conecte ao repositório

3. **GitHub Pages**
   - Configure o GitHub Pages no repositório
   - Use workflows do GitHub Actions para automatizar o deploy

### Processo de Build e Deploy

Para preparar o site para produção:

1. Execute o comando de build:
   ```bash
   npm run build
   ```

2. Isso gerará uma versão otimizada do site na pasta `.next/`

3. Para deploy na Vercel via CLI:
   ```bash
   npm install -g vercel
   vercel login
   vercel
   ```

4. Siga as instruções na tela para completar o deploy

### Configurando um Domínio Personalizado

Para usar um domínio personalizado (ex: filosofia.seusite.com.br):

1. Adquira um domínio através de um registrador (Registro.br, GoDaddy, etc.)
2. Configure os registros DNS conforme as instruções da plataforma de hospedagem
3. Verifique e ative o SSL/HTTPS para garantir a segurança do site

## Manutenção e Atualizações

### Atualizando Dependências

Para manter o site seguro e atualizado, periodicamente atualize as dependências:

```bash
npm update
```

Para verificar dependências desatualizadas:

```bash
npm outdated
```

### Backup do Conteúdo

Recomenda-se fazer backups regulares do conteúdo do site:

1. Mantenha o código-fonte em um sistema de controle de versão (como GitHub)
2. Faça backup regular dos arquivos de mídia na pasta `/public/`
3. Documente as alterações significativas feitas no site

### Monitoramento e Análise

Para monitorar o desempenho e uso do site:

1. Considere adicionar o Google Analytics ou outra ferramenta de análise
2. Monitore erros e problemas através de ferramentas como Sentry
3. Colete feedback dos usuários para melhorias contínuas

## Suporte e Recursos Adicionais

### Documentação das Tecnologias

- [Next.js Documentation](https://nextjs.org/docs)
- [Tailwind CSS Documentation](https://tailwindcss.com/docs)
- [React Documentation](https://reactjs.org/docs)

### Comunidade e Ajuda

- [Stack Overflow](https://stackoverflow.com/questions/tagged/nextjs)
- [GitHub Issues](https://github.com/vercel/next.js/issues)
- [Tailwind CSS Discord](https://discord.gg/tailwindcss)

## Conclusão

Este documento fornece as informações necessárias para utilizar e manter o Portal de Filosofia. Seguindo estas diretrizes, você poderá adicionar novos conteúdos, fazer atualizações e garantir que o site continue sendo uma ferramenta valiosa para seus alunos do ensino médio.

Para qualquer dúvida adicional ou suporte, entre em contato com a equipe de desenvolvimento.
