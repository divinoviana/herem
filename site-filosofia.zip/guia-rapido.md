# Guia Rápido: Portal de Filosofia

Este guia rápido fornece instruções básicas para começar a utilizar o Portal de Filosofia. Para informações mais detalhadas, consulte a documentação completa em `documentacao.md`.

## Visão Geral

O Portal de Filosofia é um site desenvolvido para compartilhar material didático de filosofia com alunos do ensino médio. Ele foi construído com Next.js e Tailwind CSS, oferecendo uma experiência atraente e responsiva.

## Estrutura Principal

- **Página Inicial**: Apresentação do portal e acesso rápido às principais seções
- **Áreas Temáticas**: Conteúdos organizados por períodos e correntes filosóficas
- **Recursos Didáticos**: Materiais de apoio como textos, HQs, mapas mentais e resumos
- **Atividades Interativas**: Quizzes, jogos, fóruns e chats para engajamento dos alunos
- **Sobre**: Informações sobre o portal, missão, valores e equipe
- **Seção Spinoza**: Conteúdo especial dedicado ao filósofo Baruch Spinoza

## Como Adicionar Conteúdo

### Novo Conteúdo em Áreas Temáticas
1. Navegue até `/src/app/areas-tematicas/`
2. Crie uma pasta com o nome da área (use slugs: minúsculas, sem acentos, com hífens)
3. Crie um arquivo `page.tsx` baseado nos templates existentes

### Novo Recurso Didático
1. Navegue até `/src/app/recursos-didaticos/conteudo/`
2. Crie uma pasta com o nome do recurso (use slugs)
3. Crie um arquivo `page.tsx` baseado nos templates existentes

### Nova Atividade Interativa
1. Navegue até `/src/app/atividades-interativas/`
2. Crie uma pasta com o nome da atividade (use slugs)
3. Crie um arquivo `page.tsx` baseado nos templates existentes

## Publicação do Site

Para publicar o site:
1. Execute `npm run build` para gerar a versão de produção
2. Faça o deploy em plataformas como Vercel, Netlify ou GitHub Pages
3. Para a Vercel (recomendado): instale a CLI com `npm install -g vercel`, faça login com `vercel login` e execute `vercel` para deploy

## Suporte

Para mais informações, consulte:
- Documentação completa em `documentacao.md`
- [Next.js Documentation](https://nextjs.org/docs)
- [Tailwind CSS Documentation](https://tailwindcss.com/docs)
