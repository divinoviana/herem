import Link from "next/link";

export function Footer() {
  return (
    <footer className="border-t bg-muted/40">
      <div className="container py-8 md:py-12">
        <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-4">
          <div>
            <h3 className="mb-4 text-lg font-semibold">Portal de Filosofia</h3>
            <p className="text-sm text-muted-foreground">
              Um espaço dedicado ao estudo e reflexão filosófica para alunos do ensino médio da educação básica pública do Brasil.
            </p>
          </div>
          <div>
            <h3 className="mb-4 text-lg font-semibold">Navegação</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/" className="text-muted-foreground transition-colors hover:text-foreground">
                  Início
                </Link>
              </li>
              <li>
                <Link href="/areas-tematicas" className="text-muted-foreground transition-colors hover:text-foreground">
                  Áreas Temáticas
                </Link>
              </li>
              <li>
                <Link href="/recursos-didaticos" className="text-muted-foreground transition-colors hover:text-foreground">
                  Recursos Didáticos
                </Link>
              </li>
              <li>
                <Link href="/atividades-interativas" className="text-muted-foreground transition-colors hover:text-foreground">
                  Atividades Interativas
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="mb-4 text-lg font-semibold">Áreas Temáticas</h3>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/areas-tematicas/filosofia-antiga" className="text-muted-foreground transition-colors hover:text-foreground">
                  Filosofia Antiga
                </Link>
              </li>
              <li>
                <Link href="/areas-tematicas/filosofia-moderna" className="text-muted-foreground transition-colors hover:text-foreground">
                  Filosofia Moderna
                </Link>
              </li>
              <li>
                <Link href="/areas-tematicas/etica-politica" className="text-muted-foreground transition-colors hover:text-foreground">
                  Ética e Filosofia Política
                </Link>
              </li>
              <li>
                <Link href="/areas-tematicas/filosofia-brasileira" className="text-muted-foreground transition-colors hover:text-foreground">
                  Filosofia Brasileira
                </Link>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="mb-4 text-lg font-semibold">Contato</h3>
            <ul className="space-y-2 text-sm">
              <li className="flex items-center gap-2 text-muted-foreground">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4">
                  <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                </svg>
                <span>(00) 0000-0000</span>
              </li>
              <li className="flex items-center gap-2 text-muted-foreground">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4">
                  <rect width="20" height="16" x="2" y="4" rx="2" />
                  <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7" />
                </svg>
                <span>contato@portalfilosofia.edu.br</span>
              </li>
              <li className="flex items-center gap-2 text-muted-foreground">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" className="h-4 w-4">
                  <path d="M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z" />
                  <circle cx="12" cy="10" r="3" />
                </svg>
                <span>Brasil</span>
              </li>
            </ul>
          </div>
        </div>
        <div className="mt-8 border-t pt-8 text-center text-sm text-muted-foreground">
          <p>© {new Date().getFullYear()} Portal de Filosofia. Todos os direitos reservados.</p>
        </div>
      </div>
    </footer>
  );
}
