import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";

export default function SobrePage() {
  return (
    <MainLayout>
      <section className="filosofia-hero bg-primary">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/80 to-secondary/80 opacity-90"></div>
        <div className="container relative z-10 mx-auto px-4 py-16 text-center">
          <h1 className="mb-6 text-4xl font-bold md:text-5xl lg:text-6xl">
            Sobre o Portal
          </h1>
          <p className="mx-auto mb-8 max-w-3xl text-lg md:text-xl">
            Conheça nossa missão, valores e a equipe por trás do Portal de Filosofia.
          </p>
        </div>
      </section>

      <section className="filosofia-section">
        <div className="filosofia-container">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            <div className="md:col-span-1">
              <Card className="filosofia-card sticky top-20">
                <CardHeader>
                  <CardTitle>Navegação</CardTitle>
                  <CardDescription>Explore esta página</CardDescription>
                </CardHeader>
                <CardContent>
                  <nav className="space-y-1">
                    <a 
                      href="#missao" 
                      className="block rounded-md px-3 py-2 text-sm hover:bg-muted"
                    >
                      Nossa Missão
                    </a>
                    <a 
                      href="#valores" 
                      className="block rounded-md px-3 py-2 text-sm hover:bg-muted"
                    >
                      Valores
                    </a>
                    <a 
                      href="#equipe" 
                      className="block rounded-md px-3 py-2 text-sm hover:bg-muted"
                    >
                      Equipe
                    </a>
                    <a 
                      href="#contato" 
                      className="block rounded-md px-3 py-2 text-sm hover:bg-muted"
                    >
                      Contato
                    </a>
                  </nav>
                </CardContent>
              </Card>
            </div>

            <div className="md:col-span-2">
              <div id="missao" className="scroll-mt-20">
                <h2 className="filosofia-subheading">Nossa Missão</h2>
                <div className="space-y-4">
                  <p>
                    O Portal de Filosofia tem como missão democratizar o acesso ao conhecimento filosófico, 
                    tornando-o acessível, envolvente e relevante para estudantes do ensino médio da educação 
                    básica pública do Brasil.
                  </p>
                  <p>
                    Acreditamos que a filosofia é uma ferramenta fundamental para o desenvolvimento do pensamento 
                    crítico, da autonomia intelectual e da cidadania. Por isso, buscamos criar um ambiente digital 
                    que estimule a reflexão, o questionamento e o diálogo filosófico.
                  </p>
                  <p>
                    Nosso objetivo é oferecer recursos didáticos de qualidade, atividades interativas envolventes 
                    e um espaço de troca de ideias que complementem o ensino de filosofia nas escolas, apoiando 
                    tanto professores quanto estudantes em sua jornada filosófica.
                  </p>
                </div>
              </div>

              <div id="valores" className="mt-12 scroll-mt-20">
                <h2 className="filosofia-subheading">Valores</h2>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <Card className="filosofia-card">
                    <CardHeader>
                      <CardTitle>Acessibilidade</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground">
                        Comprometemo-nos a tornar o conhecimento filosófico acessível a todos, 
                        independentemente de sua formação prévia ou condições socioeconômicas.
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="filosofia-card">
                    <CardHeader>
                      <CardTitle>Pluralidade</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground">
                        Valorizamos a diversidade de perspectivas filosóficas, reconhecendo a 
                        riqueza das diferentes tradições, culturas e abordagens do pensamento.
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="filosofia-card">
                    <CardHeader>
                      <CardTitle>Rigor</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground">
                        Comprometemo-nos com a precisão e o rigor acadêmico, mesmo ao apresentar 
                        conteúdos de forma acessível e envolvente para o público jovem.
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="filosofia-card">
                    <CardHeader>
                      <CardTitle>Diálogo</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground">
                        Promovemos o diálogo respeitoso e a troca de ideias como ferramentas 
                        essenciais para o desenvolvimento do pensamento filosófico.
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="filosofia-card">
                    <CardHeader>
                      <CardTitle>Criatividade</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground">
                        Buscamos abordagens inovadoras e criativas para o ensino de filosofia, 
                        utilizando recursos multimídia e interativos para engajar os estudantes.
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="filosofia-card">
                    <CardHeader>
                      <CardTitle>Relevância</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <p className="text-muted-foreground">
                        Conectamos o pensamento filosófico às questões contemporâneas, demonstrando 
                        sua relevância para a compreensão e transformação do mundo atual.
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </div>

              <div id="equipe" className="mt-12 scroll-mt-20">
                <h2 className="filosofia-subheading">Equipe</h2>
                <p className="mb-6">
                  O Portal de Filosofia é mantido por uma equipe de professores, pesquisadores e 
                  desenvolvedores comprometidos com a democratização do conhecimento filosófico.
                </p>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 md:grid-cols-3">
                  <Card className="filosofia-card">
                    <div className="aspect-square overflow-hidden rounded-t-lg">
                      <div className="h-full w-full bg-muted"></div>
                    </div>
                    <CardHeader>
                      <CardTitle>Prof. Silva</CardTitle>
                      <CardDescription>Coordenador do Portal</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground">
                        Professor de Filosofia com especialização em Spinoza e Filosofia Moderna. 
                        Coordena o desenvolvimento de conteúdos e a estratégia pedagógica do portal.
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="filosofia-card">
                    <div className="aspect-square overflow-hidden rounded-t-lg">
                      <div className="h-full w-full bg-muted"></div>
                    </div>
                    <CardHeader>
                      <CardTitle>Profa. Oliveira</CardTitle>
                      <CardDescription>Editora de Conteúdo</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground">
                        Professora de Filosofia com doutorado em Filosofia Antiga. Responsável pela 
                        curadoria e edição dos conteúdos didáticos do portal.
                      </p>
                    </CardContent>
                  </Card>

                  <Card className="filosofia-card">
                    <div className="aspect-square overflow-hidden rounded-t-lg">
                      <div className="h-full w-full bg-muted"></div>
                    </div>
                    <CardHeader>
                      <CardTitle>Prof. Santos</CardTitle>
                      <CardDescription>Desenvolvedor de Atividades</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground">
                        Professor de Filosofia e desenvolvedor educacional. Cria as atividades 
                        interativas e jogos filosóficos do portal.
                      </p>
                    </CardContent>
                  </Card>
                </div>
              </div>

              <div id="contato" className="mt-12 scroll-mt-20">
                <h2 className="filosofia-subheading">Contato</h2>
                <p className="mb-6">
                  Estamos sempre abertos a sugestões, parcerias e colaborações. Entre em contato conosco:
                </p>
                <Card className="filosofia-card">
                  <CardHeader>
                    <CardTitle>Fale Conosco</CardTitle>
                    <CardDescription>Envie sua mensagem</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                        <div>
                          <label htmlFor="nome" className="block text-sm font-medium mb-1">Nome</label>
                          <input 
                            type="text" 
                            id="nome" 
                            className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                            placeholder="Seu nome"
                          />
                        </div>
                        <div>
                          <label htmlFor="email" className="block text-sm font-medium mb-1">E-mail</label>
                          <input 
                            type="email" 
                            id="email" 
                            className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                            placeholder="seu.email@exemplo.com"
                          />
                        </div>
                      </div>
                      <div>
                        <label htmlFor="assunto" className="block text-sm font-medium mb-1">Assunto</label>
                        <input 
                          type="text" 
                          id="assunto" 
                          className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                          placeholder="Assunto da mensagem"
                        />
                      </div>
                      <div>
                        <label htmlFor="mensagem" className="block text-sm font-medium mb-1">Mensagem</label>
                        <textarea 
                          id="mensagem" 
                          rows={5}
                          className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
                          placeholder="Sua mensagem"
                        ></textarea>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button className="w-full">Enviar Mensagem</Button>
                  </CardFooter>
                </Card>
              </div>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
