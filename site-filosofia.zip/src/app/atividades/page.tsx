import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";

export default function AtividadesPage() {
  return (
    <MainLayout>
      <section className="filosofia-hero bg-secondary">
        <div className="absolute inset-0 bg-gradient-to-r from-secondary/80 to-accent/80 opacity-90"></div>
        <div className="container relative z-10 mx-auto px-4 py-16 text-center">
          <h1 className="mb-6 text-4xl font-bold md:text-5xl lg:text-6xl">
            Atividades Interativas
          </h1>
          <p className="mx-auto mb-8 max-w-3xl text-lg md:text-xl">
            Exercite seu pensamento filosófico com nossas atividades interativas e desafios.
          </p>
        </div>
      </section>

      <section className="filosofia-section">
        <div className="filosofia-container">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Quizzes Filosóficos</CardTitle>
                <CardDescription>Teste seus conhecimentos</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Desafie-se com perguntas sobre os principais conceitos, pensadores e correntes filosóficas. Uma forma divertida de testar e consolidar seus conhecimentos.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/atividades-interativas/quizzes">
                    Iniciar Quiz
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Fóruns de Discussão</CardTitle>
                <CardDescription>Participe de debates filosóficos</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Explore temas filosóficos contemporâneos através de debates estruturados e troca de ideias com outros estudantes e professores.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/atividades-interativas/forum">
                    Participar
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Chat Filosófico</CardTitle>
                <CardDescription>Converse em tempo real</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Participe de conversas em tempo real sobre temas filosóficos. Tire dúvidas, compartilhe ideias e aprofunde seu conhecimento através do diálogo.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/atividades-interativas/chat">
                    Entrar no Chat
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Jogos Filosóficos</CardTitle>
                <CardDescription>Aprenda jogando</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Experimente jogos interativos baseados em conceitos filosóficos. Uma forma lúdica e envolvente de explorar ideias complexas.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/atividades-interativas/jogos">
                    Jogar Agora
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Exercícios de Reflexão</CardTitle>
                <CardDescription>Desenvolva seu pensamento crítico</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Pratique o pensamento filosófico com exercícios estruturados que estimulam a reflexão crítica sobre diversos temas e problemas filosóficos.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/atividades-interativas/exercicios">
                    Começar
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Desafios Argumentativos</CardTitle>
                <CardDescription>Aprimore sua capacidade de argumentação</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Enfrente desafios que testam sua capacidade de construir, analisar e avaliar argumentos filosóficos de forma clara e consistente.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/atividades-interativas/desafios">
                    Aceitar Desafio
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>

      <section className="filosofia-section bg-muted/30">
        <div className="filosofia-container">
          <h2 className="filosofia-heading text-center">Destaque: Spinoza</h2>
          <p className="mx-auto mb-12 max-w-3xl text-center text-muted-foreground">
            Atividades interativas especiais sobre o pensamento de Baruch Spinoza.
          </p>
          
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Quiz sobre Spinoza</CardTitle>
                <CardDescription>
                  Teste seus conhecimentos sobre o filósofo
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Um quiz interativo com perguntas sobre a vida, obra e conceitos fundamentais da filosofia de Spinoza. 
                  Desafie-se e descubra quanto você sabe sobre este importante pensador.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/atividades-interativas/quizzes/spinoza">
                    Iniciar Quiz
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Modo de Spinoza</CardTitle>
                <CardDescription>
                  Jogo interativo baseado na filosofia spinozista
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Experimente o mundo através da perspectiva spinozista neste jogo interativo. 
                  Compreenda os conceitos de substância, atributos e modos enquanto navega por diferentes cenários.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/atividades-interativas/jogos/modo-spinoza">
                    Jogar Agora
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>

      <section className="filosofia-section">
        <div className="filosofia-container">
          <h2 className="filosofia-heading text-center">Participe da Comunidade</h2>
          <p className="mx-auto mb-12 max-w-3xl text-center text-muted-foreground">
            Conecte-se com outros estudantes e professores de filosofia para compartilhar ideias e aprender juntos.
          </p>
          
          <div className="mx-auto max-w-lg">
            <Card className="filosofia-card">
              <CardHeader>
                <CardTitle>Crie Sua Conta</CardTitle>
                <CardDescription>
                  Acesse recursos exclusivos
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="mb-4">
                  Ao criar uma conta no Portal de Filosofia, você poderá:
                </p>
                <ul className="list-disc pl-5 space-y-2 text-muted-foreground mb-4">
                  <li>Participar dos fóruns de discussão</li>
                  <li>Entrar nos chats filosóficos</li>
                  <li>Salvar seu progresso nos quizzes e jogos</li>
                  <li>Compartilhar suas próprias reflexões</li>
                  <li>Receber notificações sobre novos conteúdos</li>
                </ul>
                <p>
                  A participação na comunidade enriquece a experiência de aprendizado filosófico.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/cadastro">
                    Criar Conta
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
