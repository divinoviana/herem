import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Link from "next/link";

interface ConteudoPageProps {
  params: {
    slug: string;
  };
}

export default function ConteudoPage({ params }: ConteudoPageProps) {
  // Dados que seriam carregados dinamicamente com base no slug
  const conteudoData = getConteudoData(params.slug);

  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="filosofia-hero bg-secondary">
        <div className="absolute inset-0 bg-gradient-to-r from-secondary/80 to-accent/80 opacity-90"></div>
        <div className="container relative z-10 mx-auto px-4 py-16 text-center">
          <h1 className="mb-6 text-4xl font-bold md:text-5xl lg:text-6xl">
            {conteudoData.title}
          </h1>
          <p className="mx-auto mb-8 max-w-3xl text-lg md:text-xl">
            {conteudoData.description}
          </p>
        </div>
      </section>

      {/* Conteúdo Principal */}
      <section className="filosofia-section">
        <div className="filosofia-container">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
            {/* Sidebar */}
            <div className="md:col-span-1">
              <Card className="filosofia-card sticky top-20">
                <CardHeader>
                  <CardTitle>Índice</CardTitle>
                  <CardDescription>Navegue pelo conteúdo</CardDescription>
                </CardHeader>
                <CardContent>
                  <nav className="space-y-1">
                    {conteudoData.sections.map((section, index) => (
                      <a 
                        key={index} 
                        href={`#section-${index}`}
                        className="block rounded-md px-3 py-2 text-sm hover:bg-muted"
                      >
                        {section.title}
                      </a>
                    ))}
                  </nav>
                </CardContent>
                <CardFooter>
                  <div className="flex w-full flex-col gap-2">
                    <Button asChild variant="outline" className="w-full">
                      <Link href={conteudoData.backLink.href}>
                        {conteudoData.backLink.label}
                      </Link>
                    </Button>
                    {conteudoData.downloadLink && (
                      <Button asChild className="w-full">
                        <Link href={conteudoData.downloadLink.href}>
                          {conteudoData.downloadLink.label}
                        </Link>
                      </Button>
                    )}
                  </div>
                </CardFooter>
              </Card>
            </div>

            {/* Conteúdo Principal */}
            <div className="md:col-span-3">
              <Card className="filosofia-card">
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div>
                      <CardTitle>{conteudoData.title}</CardTitle>
                      <CardDescription>{conteudoData.metadata}</CardDescription>
                    </div>
                    {conteudoData.author && (
                      <div className="text-right text-sm">
                        <p>Por: <span className="font-medium">{conteudoData.author}</span></p>
                        <p className="text-muted-foreground">{conteudoData.date}</p>
                      </div>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-8">
                    {conteudoData.sections.map((section, index) => (
                      <div key={index} id={`section-${index}`} className="scroll-mt-20">
                        <h2 className="mb-4 text-2xl font-bold text-primary">{section.title}</h2>
                        <div className="space-y-4">
                          {section.content.map((paragraph, pIndex) => (
                            <p key={pIndex}>{paragraph}</p>
                          ))}
                        </div>
                        {section.image && (
                          <div className="mt-4 overflow-hidden rounded-lg">
                            <div className="h-64 w-full bg-muted"></div>
                            <p className="mt-2 text-center text-sm text-muted-foreground">{section.image.caption}</p>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </CardContent>
                <CardFooter className="flex-col items-start border-t">
                  {conteudoData.references && (
                    <div className="w-full">
                      <h3 className="mb-2 text-lg font-semibold">Referências</h3>
                      <ul className="list-inside list-disc space-y-1 text-sm text-muted-foreground">
                        {conteudoData.references.map((reference, index) => (
                          <li key={index}>{reference}</li>
                        ))}
                      </ul>
                    </div>
                  )}
                  
                  {conteudoData.relatedContent && (
                    <div className="mt-6 w-full">
                      <h3 className="mb-4 text-lg font-semibold">Conteúdos Relacionados</h3>
                      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                        {conteudoData.relatedContent.map((item, index) => (
                          <Card key={index} className="border border-muted">
                            <CardHeader className="p-4">
                              <CardTitle className="text-base">{item.title}</CardTitle>
                              <CardDescription>{item.type}</CardDescription>
                            </CardHeader>
                            <CardFooter className="p-4 pt-0">
                              <Button asChild variant="outline" className="w-full">
                                <Link href={item.href}>Acessar</Link>
                              </Button>
                            </CardFooter>
                          </Card>
                        ))}
                      </div>
                    </div>
                  )}
                </CardFooter>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}

// Função para obter dados do conteúdo com base no slug
function getConteudoData(slug: string) {
  // Aqui você implementaria a lógica para buscar dados do backend
  // Por enquanto, retornamos dados de exemplo para o conteúdo "etica-spinoza"
  
  const conteudosData: Record<string, any> = {
    "etica-spinoza": {
      title: "A Ética de Spinoza: Uma Introdução",
      description: "Uma introdução à obra-prima filosófica de Baruch Spinoza, explorando seus conceitos fundamentais e sua relevância contemporânea.",
      metadata: "Texto • Filosofia Moderna • Spinoza",
      author: "Prof. Silva",
      date: "10/04/2025",
      backLink: {
        label: "Voltar para Spinoza",
        href: "/areas-tematicas/filosofia-moderna/spinoza"
      },
      downloadLink: {
        label: "Baixar PDF",
        href: "/downloads/etica-spinoza.pdf"
      },
      sections: [
        {
          title: "Introdução à Ética",
          content: [
            "A Ética (Ethica, ordine geometrico demonstrata) é a obra-prima de Baruch Spinoza, publicada postumamente em 1677. Escrita em latim e estruturada segundo o método geométrico inspirado em Euclides, a obra apresenta um sistema filosófico completo que abrange metafísica, epistemologia, psicologia e ética.",
            "Dividida em cinco partes, a Ética desenvolve uma visão monista da realidade, identificando Deus com a Natureza, e propõe um caminho para a liberdade humana através do conhecimento adequado de nossas paixões e da compreensão da necessidade que governa todas as coisas."
          ]
        },
        {
          title: "Estrutura e Método",
          content: [
            "A Ética é estruturada segundo o método geométrico, começando com definições e axiomas, a partir dos quais Spinoza deriva proposições através de demonstrações lógicas. Esta abordagem reflete sua convicção de que a realidade possui uma estrutura necessária e racional que pode ser compreendida pela razão humana.",
            "As cinco partes da obra são: I. De Deus; II. Da Natureza e Origem da Mente; III. Da Origem e Natureza dos Afetos; IV. Da Servidão Humana ou da Força dos Afetos; V. Da Potência do Intelecto ou da Liberdade Humana."
          ],
          image: {
            caption: "Página original da Ética de Spinoza, mostrando o método geométrico com definições, axiomas e proposições."
          }
        },
        {
          title: "Deus ou a Natureza",
          content: [
            "Na Parte I da Ética, Spinoza estabelece sua metafísica monista, argumentando que existe apenas uma substância infinita, que ele identifica como 'Deus ou a Natureza' (Deus sive Natura). Esta substância possui infinitos atributos, dos quais conhecemos apenas dois: pensamento e extensão.",
            "Para Spinoza, Deus não é um ser transcendente e pessoal que criou o mundo com um propósito, mas a própria ordem imanente da natureza. Tudo o que existe é um modo ou afecção desta substância única, expressando-se de maneiras determinadas e necessárias."
          ]
        },
        {
          title: "Mente e Corpo",
          content: [
            "Na Parte II, Spinoza aborda a natureza da mente humana e sua relação com o corpo. Rejeitando o dualismo cartesiano, ele argumenta que mente e corpo não são substâncias distintas, mas dois aspectos (modos dos atributos pensamento e extensão) da mesma realidade.",
            "Segundo Spinoza, 'a ordem e conexão das ideias é a mesma que a ordem e conexão das coisas'. Esta é sua famosa doutrina do paralelismo, que estabelece uma correspondência entre processos mentais e físicos sem causalidade entre eles."
          ]
        },
        {
          title: "Teoria dos Afetos",
          content: [
            "A Parte III desenvolve uma teoria naturalista dos afetos (emoções), tratando-os não como vícios ou imperfeições, mas como fenômenos naturais que seguem as mesmas leis necessárias que governam todos os aspectos da realidade.",
            "Spinoza identifica três afetos primários: desejo (conatus, o esforço para perseverar no ser), alegria (aumento da potência de agir) e tristeza (diminuição da potência de agir). Todos os outros afetos são derivados destes três."
          ]
        },
        {
          title: "Servidão e Liberdade",
          content: [
            "Nas Partes IV e V, Spinoza aborda a questão da servidão humana às paixões e o caminho para a liberdade. Para ele, somos 'servos' quando somos dominados por paixões que não compreendemos adequadamente, agindo como causas parciais ou inadequadas de nossas ações.",
            "A liberdade, por outro lado, não consiste em livre-arbítrio (que Spinoza rejeita como ilusório), mas na compreensão adequada de nossas paixões e da necessidade que governa todas as coisas. Através do conhecimento, podemos transformar paixões passivas em afetos ativos e alcançar a beatitude (felicidade suprema)."
          ]
        },
        {
          title: "Amor Intelectual a Deus",
          content: [
            "O ponto culminante da Ética é a doutrina do 'amor intelectual a Deus' (amor Dei intellectualis), apresentada na Parte V. Este é o estado mais elevado da mente humana, alcançado quando compreendemos intuitivamente nossa relação com a totalidade da Natureza.",
            "Neste estado, aceitamos a necessidade de todas as coisas e experimentamos uma alegria que não está sujeita às flutuações da fortuna. Para Spinoza, esta é a verdadeira liberdade e beatitude, acessível a todos através do exercício da razão."
          ]
        },
        {
          title: "Relevância Contemporânea",
          content: [
            "Apesar de ter sido escrita no século XVII, a Ética de Spinoza continua relevante para discussões contemporâneas em diversos campos. Sua visão monista e naturalista antecipou desenvolvimentos na ciência moderna, enquanto sua teoria dos afetos influenciou a psicologia e a neurociência.",
            "Filósofos contemporâneos como Gilles Deleuze e Antonio Negri encontraram na obra de Spinoza recursos para pensar questões políticas atuais, enquanto sua ética da alegria e da potência oferece uma alternativa às morais baseadas em culpa e obediência."
          ]
        }
      ],
      references: [
        "SPINOZA, Baruch. Ética. Tradução de Tomaz Tadeu. Belo Horizonte: Autêntica, 2009.",
        "DELEUZE, Gilles. Espinosa: Filosofia Prática. São Paulo: Escuta, 2002.",
        "CHAUÍ, Marilena. A Nervura do Real: Imanência e Liberdade em Espinosa. São Paulo: Companhia das Letras, 1999.",
        "GARRETT, Don (org.). The Cambridge Companion to Spinoza. Cambridge: Cambridge University Press, 1996."
      ],
      relatedContent: [
        {
          title: "Vida e Obra de Spinoza",
          type: "Biografia",
          href: "/recursos-didaticos/biografias/spinoza"
        },
        {
          title: "Mapa Conceitual: Sistema de Spinoza",
          type: "Mapa Mental",
          href: "/recursos-didaticos/mapas/sistema-spinoza"
        },
        {
          title: "Quiz sobre Spinoza",
          type: "Atividade Interativa",
          href: "/atividades-interativas/quizzes/spinoza"
        },
        {
          title: "Fórum: Spinoza e o Monismo",
          type: "Discussão",
          href: "/atividades-interativas/forum/spinoza"
        }
      ]
    },
    // Adicione dados para outros conteúdos conforme necessário
  };

  // Retorna os dados do conteúdo solicitado ou um objeto padrão se não encontrar
  return conteudosData[slug] || {
    title: "Conteúdo",
    description: "Descrição do conteúdo.",
    metadata: "Tipo • Categoria",
    backLink: {
      label: "Voltar",
      href: "/"
    },
    sections: [
      {
        title: "Conteúdo não encontrado",
        content: ["O conteúdo solicitado não está disponível."]
      }
    ]
  };
}
