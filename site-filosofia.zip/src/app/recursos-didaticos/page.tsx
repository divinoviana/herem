import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";

export default function RecursosDidaticosPage() {
  return (
    <MainLayout>
      <section className="filosofia-hero bg-accent">
        <div className="absolute inset-0 bg-gradient-to-r from-accent/80 to-primary/80 opacity-90"></div>
        <div className="container relative z-10 mx-auto px-4 py-16 text-center">
          <h1 className="mb-6 text-4xl font-bold md:text-5xl lg:text-6xl">
            Recursos Didáticos
          </h1>
          <p className="mx-auto mb-8 max-w-3xl text-lg md:text-xl">
            Materiais de apoio para enriquecer seus estudos e aprofundar seus conhecimentos filosóficos.
          </p>
        </div>
      </section>

      <section className="filosofia-section">
        <div className="filosofia-container">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Textos e Artigos</CardTitle>
                <CardDescription>Leituras selecionadas para aprofundamento</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                  <li>Textos clássicos adaptados</li>
                  <li>Artigos introdutórios</li>
                  <li>Análises de obras filosóficas</li>
                  <li>Comentários sobre pensadores</li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/recursos-didaticos/textos">
                    Acessar
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Histórias em Quadrinhos</CardTitle>
                <CardDescription>Filosofia em formato visual</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Explore conceitos filosóficos através de histórias em quadrinhos que tornam as ideias mais acessíveis e envolventes para estudantes.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/recursos-didaticos/hq">
                    Acessar
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Mapas Mentais</CardTitle>
                <CardDescription>Visualização de conceitos e relações</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Mapas conceituais que ajudam a visualizar as relações entre diferentes ideias, pensadores e correntes filosóficas.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/recursos-didaticos/mapas">
                    Acessar
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Resumos</CardTitle>
                <CardDescription>Sínteses de obras e conceitos</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Resumos concisos das principais obras filosóficas e conceitos fundamentais, facilitando a compreensão e revisão.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/recursos-didaticos/resumos">
                    Acessar
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Multimídia</CardTitle>
                <CardDescription>Conteúdos audiovisuais sobre filosofia</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                  <li>Vídeos explicativos</li>
                  <li>Podcasts filosóficos</li>
                  <li>Infográficos interativos</li>
                  <li>Apresentações dinâmicas</li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/recursos-didaticos/multimidia">
                    Acessar
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Material de Estudo</CardTitle>
                <CardDescription>Recursos para aprendizado estruturado</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                  <li>Guias de estudo</li>
                  <li>Glossário filosófico</li>
                  <li>Linha do tempo do pensamento</li>
                  <li>Planos de aula</li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/recursos-didaticos/material-estudo">
                    Acessar
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>

      <section className="filosofia-section bg-muted/30">
        <div className="filosofia-container">
          <h2 className="filosofia-heading text-center">Destaque: Spinoza</h2>
          <p className="mx-auto mb-12 max-w-3xl text-center text-muted-foreground">
            Materiais didáticos especiais sobre o pensamento de Baruch Spinoza.
          </p>
          
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2">
            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>A Ética de Spinoza: Uma Introdução</CardTitle>
                <CardDescription>
                  Texto explicativo sobre a obra-prima de Spinoza
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Uma introdução acessível à Ética de Spinoza, explicando seus conceitos fundamentais, 
                  sua estrutura geométrica e sua relevância para o pensamento contemporâneo.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/recursos-didaticos/conteudo/etica-spinoza">
                    Ler Agora
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Mapa Conceitual: Sistema de Spinoza</CardTitle>
                <CardDescription>
                  Visualização das relações entre os conceitos spinozistas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Um mapa mental detalhado que ilustra as relações entre os principais conceitos da filosofia 
                  de Spinoza: substância, atributos, modos, conatus, afetos e liberdade.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/recursos-didaticos/mapas/sistema-spinoza">
                    Visualizar
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>

      <section className="filosofia-section">
        <div className="filosofia-container">
          <h2 className="filosofia-heading text-center">Compartilhe Seus Materiais</h2>
          <p className="mx-auto mb-12 max-w-3xl text-center text-muted-foreground">
            Este portal é um espaço colaborativo. Professores e estudantes podem compartilhar seus próprios materiais didáticos para enriquecer nossa biblioteca de recursos.
          </p>
          
          <div className="mx-auto max-w-lg">
            <Card className="filosofia-card">
              <CardHeader>
                <CardTitle>Como Compartilhar</CardTitle>
                <CardDescription>
                  Contribua com seus materiais didáticos
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="mb-4">
                  Você pode compartilhar diversos tipos de materiais didáticos:
                </p>
                <ul className="list-disc pl-5 space-y-2 text-muted-foreground mb-4">
                  <li>Textos e artigos</li>
                  <li>Histórias em quadrinhos</li>
                  <li>Mapas mentais</li>
                  <li>Resumos</li>
                  <li>Recursos multimídia</li>
                  <li>Materiais de estudo</li>
                </ul>
                <p>
                  Todos os materiais passarão por uma revisão antes de serem publicados no portal.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/recursos-didaticos/compartilhar">
                    Compartilhar Material
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
