import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import Link from "next/link";

interface PerfilFilosofoPageProps {
  params: {
    slug: string;
  };
}

export default function PerfilFilosofoPage({ params }: PerfilFilosofoPageProps) {
  // Dados que seriam carregados dinamicamente com base no slug
  const filosofoData = getFilosofoData(params.slug);

  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="filosofia-hero">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/80 to-accent/80 opacity-90"></div>
        <div className="container relative z-10 mx-auto px-4 py-24 text-center">
          <h1 className="mb-6 text-4xl font-bold md:text-5xl lg:text-6xl">
            {filosofoData.name}
          </h1>
          <p className="mx-auto mb-8 max-w-3xl text-lg md:text-xl">
            {filosofoData.shortDescription}
          </p>
          <div className="flex justify-center">
            <div className="inline-flex items-center rounded-full bg-background/20 px-4 py-1 text-sm backdrop-blur">
              <span>{filosofoData.period}</span>
            </div>
          </div>
        </div>
      </section>

      {/* Conteúdo Principal */}
      <section className="filosofia-section">
        <div className="filosofia-container">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            {/* Sidebar */}
            <div className="md:col-span-1">
              <Card className="filosofia-card sticky top-20">
                <div className="aspect-square overflow-hidden rounded-t-lg">
                  <div className="h-full w-full bg-muted"></div>
                </div>
                <CardHeader>
                  <CardTitle>{filosofoData.name}</CardTitle>
                  <CardDescription>{filosofoData.period}</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <h3 className="mb-1 text-sm font-medium text-muted-foreground">Nascimento</h3>
                      <p>{filosofoData.birth}</p>
                    </div>
                    <div>
                      <h3 className="mb-1 text-sm font-medium text-muted-foreground">Morte</h3>
                      <p>{filosofoData.death}</p>
                    </div>
                    <div>
                      <h3 className="mb-1 text-sm font-medium text-muted-foreground">Nacionalidade</h3>
                      <p>{filosofoData.nationality}</p>
                    </div>
                    <div>
                      <h3 className="mb-1 text-sm font-medium text-muted-foreground">Corrente Filosófica</h3>
                      <p>{filosofoData.school}</p>
                    </div>
                    <div>
                      <h3 className="mb-1 text-sm font-medium text-muted-foreground">Principais Obras</h3>
                      <ul className="list-inside list-disc text-sm">
                        {filosofoData.mainWorks.map((work, index) => (
                          <li key={index}>{work}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                </CardContent>
                <CardFooter>
                  <Button asChild variant="outline" className="w-full">
                    <Link href={filosofoData.areaLink.href}>
                      {filosofoData.areaLink.label}
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
            </div>

            {/* Conteúdo Principal */}
            <div className="md:col-span-2">
              <Tabs defaultValue="biografia" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="biografia">Biografia</TabsTrigger>
                  <TabsTrigger value="pensamento">Pensamento</TabsTrigger>
                  <TabsTrigger value="obras">Obras</TabsTrigger>
                  <TabsTrigger value="legado">Legado</TabsTrigger>
                </TabsList>
                
                {/* Biografia */}
                <TabsContent value="biografia" className="mt-6">
                  <h2 className="filosofia-subheading">Biografia</h2>
                  <div className="space-y-4">
                    {filosofoData.biography.map((paragraph, index) => (
                      <p key={index}>{paragraph}</p>
                    ))}
                  </div>
                  
                  {filosofoData.timelineTitle && (
                    <>
                      <h3 className="mt-8 text-xl font-semibold text-primary">{filosofoData.timelineTitle}</h3>
                      <div className="mt-4 space-y-4">
                        {filosofoData.timeline.map((item, index) => (
                          <div key={index} className="flex gap-4">
                            <div className="flex flex-col items-center">
                              <div className="h-6 w-6 rounded-full bg-primary text-center text-xs text-primary-foreground flex items-center justify-center">
                                {index + 1}
                              </div>
                              {index < filosofoData.timeline.length - 1 && (
                                <div className="h-full w-0.5 bg-border"></div>
                              )}
                            </div>
                            <div className="pb-6">
                              <h4 className="text-lg font-medium">{item.year}</h4>
                              <p className="mt-2">{item.event}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </>
                  )}
                </TabsContent>
                
                {/* Pensamento */}
                <TabsContent value="pensamento" className="mt-6">
                  <h2 className="filosofia-subheading">Pensamento Filosófico</h2>
                  <div className="space-y-4">
                    {filosofoData.philosophy.map((paragraph, index) => (
                      <p key={index}>{paragraph}</p>
                    ))}
                  </div>
                  
                  <h3 className="mt-8 text-xl font-semibold text-primary">Conceitos-Chave</h3>
                  <div className="mt-4 grid grid-cols-1 gap-4 md:grid-cols-2">
                    {filosofoData.keyConcepts.map((concept, index) => (
                      <Card key={index} className="filosofia-card">
                        <CardHeader>
                          <CardTitle>{concept.title}</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-muted-foreground">{concept.description}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
                
                {/* Obras */}
                <TabsContent value="obras" className="mt-6">
                  <h2 className="filosofia-subheading">Principais Obras</h2>
                  <div className="space-y-6">
                    {filosofoData.works.map((work, index) => (
                      <div key={index} className="border-b pb-6 last:border-0">
                        <h3 className="mb-2 text-xl font-semibold text-primary">{work.title} ({work.year})</h3>
                        <p className="mb-4">{work.description}</p>
                        {work.keyIdeas && (
                          <div>
                            <h4 className="mb-2 text-sm font-medium text-muted-foreground">Ideias Principais:</h4>
                            <ul className="list-inside list-disc space-y-1 pl-4">
                              {work.keyIdeas.map((idea, ideaIndex) => (
                                <li key={ideaIndex}>{idea}</li>
                              ))}
                            </ul>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </TabsContent>
                
                {/* Legado */}
                <TabsContent value="legado" className="mt-6">
                  <h2 className="filosofia-subheading">Legado e Influência</h2>
                  <div className="space-y-4">
                    {filosofoData.legacy.map((paragraph, index) => (
                      <p key={index}>{paragraph}</p>
                    ))}
                  </div>
                  
                  {filosofoData.quotes && (
                    <>
                      <h3 className="mt-8 text-xl font-semibold text-primary">Citações Célebres</h3>
                      <div className="mt-4 space-y-4">
                        {filosofoData.quotes.map((quote, index) => (
                          <blockquote key={index} className="border-l-4 border-primary bg-muted/30 p-4 italic">
                            "{quote.text}"
                            <footer className="mt-2 text-right text-sm text-muted-foreground">— {filosofoData.name}, {quote.source}</footer>
                          </blockquote>
                        ))}
                      </div>
                    </>
                  )}
                  
                  {filosofoData.influencedBy && (
                    <>
                      <h3 className="mt-8 text-xl font-semibold text-primary">Influências</h3>
                      <div className="mt-4 flex flex-wrap gap-2">
                        {filosofoData.influencedBy.map((philosopher, index) => (
                          <div key={index} className="flex items-center gap-2 rounded-full bg-muted px-3 py-1">
                            <Avatar className="h-6 w-6">
                              <AvatarFallback>{philosopher.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <span className="text-sm">{philosopher.name}</span>
                          </div>
                        ))}
                      </div>
                    </>
                  )}
                  
                  {filosofoData.influenced && (
                    <>
                      <h3 className="mt-8 text-xl font-semibold text-primary">Pensadores Influenciados</h3>
                      <div className="mt-4 flex flex-wrap gap-2">
                        {filosofoData.influenced.map((philosopher, index) => (
                          <div key={index} className="flex items-center gap-2 rounded-full bg-muted px-3 py-1">
                            <Avatar className="h-6 w-6">
                              <AvatarFallback>{philosopher.name.charAt(0)}</AvatarFallback>
                            </Avatar>
                            <span className="text-sm">{philosopher.name}</span>
                          </div>
                        ))}
                      </div>
                    </>
                  )}
                </TabsContent>
              </Tabs>
              
              {/* Recursos Relacionados */}
              <div className="mt-8">
                <h2 className="filosofia-subheading">Recursos Relacionados</h2>
                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
                  {filosofoData.relatedResources.map((resource, index) => (
                    <Card key={index} className="filosofia-card">
                      <CardHeader>
                        <CardTitle className="text-base">{resource.title}</CardTitle>
                        <CardDescription>{resource.type}</CardDescription>
                      </CardHeader>
                      <CardFooter>
                        <Button asChild variant="outline" className="w-full">
                          <Link href={resource.href}>{resource.buttonText}</Link>
                        </Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}

// Função para obter dados do filósofo com base no slug
function getFilosofoData(slug: string) {
  // Aqui você implementaria a lógica para buscar dados do backend
  // Por enquanto, retornamos dados de exemplo para "spinoza"
  
  const filosofosData: Record<string, any> = {
    "spinoza": {
      name: "Baruch Spinoza",
      shortDescription: "Filósofo racionalista holandês do século XVII, conhecido por seu monismo e por identificar Deus com a Natureza.",
      period: "1632-1677",
      birth: "24 de novembro de 1632, Amsterdã, Países Baixos",
      death: "21 de fevereiro de 1677, Haia, Países Baixos",
      nationality: "Holandês (de origem portuguesa sefardita)",
      school: "Racionalismo",
      mainWorks: [
        "Ética (1677)",
        "Tratado Teológico-Político (1670)",
        "Tratado Político (inacabado)",
        "Tratado da Reforma do Entendimento"
      ],
      areaLink: {
        label: "Voltar para Filosofia Moderna",
        href: "/areas-tematicas/filosofia-moderna"
      },
      biography: [
        "Baruch Spinoza (também conhecido como Benedictus de Spinoza) nasceu em 24 de novembro de 1632 em Amsterdã, nos Países Baixos, em uma família de judeus sefarditas que haviam fugido de Portugal para escapar da perseguição religiosa. Seu pai, Miguel de Espinoza, era um comerciante bem-sucedido, e o jovem Baruch recebeu uma educação tradicional judaica na congregação Talmud Torá.",
        "Desde cedo, Spinoza demonstrou uma mente inquieta e questionadora. Estudou hebraico e os textos sagrados judaicos, mas também se interessou pela filosofia e ciência contemporâneas, entrando em contato com o pensamento de Descartes, Hobbes e outros filósofos modernos. Sua educação secular foi ampliada pelo contato com círculos intelectuais cristãos liberais e pelo estudo do latim com o ex-jesuíta Franciscus van den Enden.",
        "Em 1656, aos 23 anos, Spinoza foi excomungado (herem) da comunidade judaica de Amsterdã por suas visões heterodoxas. O decreto de excomunhão, excepcionalmente severo, proibia qualquer contato com ele e mencionava 'horrendas heresias'. Embora as razões exatas não sejam completamente conhecidas, suas ideias sobre Deus, a imortalidade da alma e a autoridade da Torá certamente divergiam da ortodoxia.",
        "Após a excomunhão, Spinoza adotou o nome Benedictus (versão latina de Baruch) e se afastou da comunidade judaica. Mudou-se para Rijnsburg e depois para Voorburg, nas proximidades de Haia, onde viveu modestamente como polidor de lentes ópticas, profissão que lhe permitia independência financeira e tempo para seus estudos filosóficos.",
        "Apesar de ter recebido ofertas de posições acadêmicas, incluindo uma cátedra na Universidade de Heidelberg, Spinoza preferiu manter sua independência intelectual. Cultivou amizades com cientistas, teólogos liberais e figuras políticas, mantendo uma extensa correspondência que constitui uma importante fonte para compreender seu pensamento.",
        "Em 1670, publicou anonimamente o Tratado Teológico-Político, obra que defendia a liberdade de pensamento e criticava a autoridade religiosa, causando grande controvérsia. Sua obra-prima, a Ética, foi concluída em 1675, mas Spinoza decidiu não publicá-la durante sua vida devido às possíveis repercussões negativas.",
        "Spinoza morreu em 21 de fevereiro de 1677, aos 44 anos, provavelmente devido a uma doença respiratória agravada pela inalação de pó de vidro de seu trabalho como polidor de lentes. Após sua morte, seus amigos publicaram suas obras completas, incluindo a Ética, que viria a exercer profunda influência no desenvolvimento da filosofia ocidental."
      ],
      timelineTitle: "Cronologia da Vida de Spinoza",
      timeline: [
        {
          year: "1632",
          event: "Nascimento em Amsterdã, em uma família de judeus sefarditas portugueses."
        },
        {
          year: "1638",
          event: "Morte de sua mãe, Hana Debora."
        },
        {
          year: "1654",
          event: "Morte de seu pai, Miguel de Espinoza. Spinoza assume os negócios da família com seu irmão."
        },
        {
          year: "1656",
          event: "Excomunhão (herem) da comunidade judaica de Amsterdã por suas visões heterodoxas."
        },
        {
          year: "1660",
          event: "Muda-se para Rijnsburg, onde começa a escrever o Tratado da Reforma do Entendimento."
        },
        {
          year: "1663",
          event: "Publica Princípios da Filosofia de Descartes, sua única obra publicada com seu nome em vida."
        },
        {
          year: "1670",
          event: "Publica anonimamente o Tratado Teológico-Político, causando grande controvérsia."
        },
        {
          year: "1673",
          event: "Recusa oferta de cátedra na Universidade de Heidelberg para preservar sua liberdade de pensamento."
        },
        {
          year: "1675",
          event: "Conclui a Ética, mas decide não publicá-la durante sua vida."
        },
        {
          year: "1677",
          event: "Morte em Haia, aos 44 anos. Seus amigos publicam suas obras completas, incluindo a Ética."
        }
      ],
      philosophy: [
        "O pensamento de Spinoza representa uma das mais originais e sistemáticas contribuições à filosofia ocidental. Seu sistema filosófico é caracterizado por um monismo rigoroso, determinismo e uma visão naturalista da realidade que rejeita qualquer forma de transcendência ou finalismo.",
        "No centro da metafísica spinozista está a ideia de que existe apenas uma substância infinita, que ele identifica como 'Deus ou Natureza' (Deus sive Natura). Esta substância possui infinitos atributos, dos quais os seres humanos podem conhecer apenas dois: pensamento e extensão. Todos os seres particulares, incluindo os humanos, são modos ou afecções desta substância única, expressando-se de maneiras determinadas e necessárias.",
        "Ao identificar Deus com a Natureza, Spinoza rejeita a concepção tradicional de um Deus pessoal e transcendente que criou o mundo com um propósito. Para ele, Deus não age com finalidades, não tem vontade no sentido humano e não está separado do mundo natural. Esta visão, frequentemente descrita como panteísmo, foi considerada herética tanto por judeus quanto por cristãos de sua época.",
        "Na epistemologia, Spinoza distingue três tipos de conhecimento: opinião ou imaginação (conhecimento inadequado baseado em experiência sensorial e relatos), razão (conhecimento adequado de propriedades comuns) e intuição (conhecimento imediato da essência das coisas). O objetivo do conhecimento é compreender a necessidade que governa todas as coisas.",
        "Sua teoria dos afetos, desenvolvida na Parte III da Ética, trata as emoções não como vícios ou imperfeições, mas como fenômenos naturais que seguem as mesmas leis necessárias que governam todos os aspectos da realidade. Spinoza identifica três afetos primários: desejo (conatus, o esforço para perseverar no ser), alegria (aumento da potência de agir) e tristeza (diminuição da potência de agir).",
        "A ética de Spinoza é eudemonista, buscando o caminho para a verdadeira felicidade (beatitude). Para ele, somos 'servos' quando dominados por paixões que não compreendemos adequadamente. A liberdade não consiste em livre-arbítrio (que Spinoza rejeita como ilusório), mas na compreensão adequada de nossas paixões e da necessidade que governa todas as coisas. Através do conhecimento, podemos transformar paixões passivas em afetos ativos.",
        "O ponto culminante de sua filosofia é a doutrina do 'amor intelectual a Deus' (amor Dei intellectualis), o estado mais elevado da mente humana, alcançado quando compreendemos intuitivamente nossa relação com a totalidade da Natureza. Neste estado, aceitamos a necessidade de todas as coisas e experimentamos uma alegria que não está sujeita às flutuações da fortuna."
      ],
      keyConcepts: [
        {
          title: "Substância",
          description: "Para Spinoza, existe apenas uma substância infinita (Deus ou Natureza), que é causa de si mesma e existe necessariamente. Esta substância possui infinitos atributos, dos quais conhecemos apenas dois: pensamento e extensão."
        },
        {
          title: "Atributos",
          description: "Os atributos são as formas pelas quais percebemos a substância. Embora a substância tenha infinitos atributos, os seres humanos só podem conhecer dois: o pensamento (mundo das ideias) e a extensão (mundo físico)."
        },
        {
          title: "Modos",
          description: "Os modos são modificações ou afecções da substância. Todos os seres particulares (incluindo os humanos) são modos da substância divina, expressões finitas e determinadas de Deus/Natureza."
        },
        {
          title: "Conatus",
          description: "O conatus é o esforço pelo qual cada coisa se esforça para perseverar em seu ser. É a essência atual de cada modo, seu impulso fundamental de autopreservação e aumento de potência."
        },
        {
          title: "Determinismo",
          description: "Spinoza defende um determinismo rigoroso: tudo o que acontece é necessário e não poderia ser diferente. Não há contingência na natureza, apenas nossa ignorância das causas nos faz perceber eventos como contingentes."
        },
        {
          title: "Afetos",
          description: "Os afetos são as afecções do corpo que aumentam ou diminuem sua potência de agir, junto com as ideias dessas afecções. Spinoza identifica três afetos primários: alegria (aumento de potência), tristeza (diminuição de potência) e desejo."
        }
      ],
      works: [
        {
          title: "Ética",
          year: "1677 (póstuma)",
          description: "A obra-prima de Spinoza, escrita segundo o método geométrico com definições, axiomas e proposições. Dividida em cinco partes, apresenta um sistema filosófico completo que abrange metafísica, epistemologia, psicologia e ética.",
          keyIdeas: [
            "Monismo: existe apenas uma substância (Deus ou Natureza)",
            "Paralelismo psicofísico: mente e corpo são dois aspectos da mesma realidade",
            "Teoria dos afetos: análise naturalista das emoções humanas",
            "Determinismo: tudo o que acontece é necessário",
            "Liberdade como compreensão da necessidade"
          ]
        },
        {
          title: "Tratado Teológico-Político",
          year: "1670",
          description: "Publicado anonimamente, este tratado defende a liberdade de pensamento e expressão, e desenvolve uma abordagem histórico-crítica da Bíblia. Argumenta pela separação entre filosofia e teologia, e defende a democracia como forma de governo.",
          keyIdeas: [
            "Crítica à superstição e ao dogmatismo religioso",
            "Método histórico-crítico de interpretação bíblica",
            "Defesa da liberdade de pensamento e expressão",
            "Separação entre filosofia (busca da verdade) e teologia (promoção da obediência)",
            "Argumentos em favor da democracia"
          ]
        },
        {
          title: "Tratado Político",
          year: "1677 (inacabado)",
          description: "Obra inacabada devido à morte de Spinoza, analisa diferentes formas de governo (monarquia, aristocracia e democracia) de uma perspectiva realista, inspirada em Maquiavel, mas com princípios derivados de sua metafísica.",
          keyIdeas: [
            "Análise realista da política, baseada nas paixões humanas",
            "Crítica ao utopismo político",
            "Defesa da estabilidade institucional",
            "Concepção de direito natural como poder",
            "Valorização da democracia como regime mais natural"
          ]
        },
        {
          title: "Tratado da Reforma do Entendimento",
          year: "c. 1662 (inacabado)",
          description: "Obra inicial e inacabada que aborda questões epistemológicas, buscando estabelecer um método para alcançar o conhecimento verdadeiro e a felicidade suprema.",
          keyIdeas: [
            "Busca do bem supremo como objetivo da filosofia",
            "Crítica aos bens convencionais (riqueza, honra, prazer)",
            "Método para purificar o intelecto",
            "Distinção entre diferentes tipos de percepção",
            "Teoria da definição perfeita"
          ]
        }
      ],
      legacy: [
        "O legado de Spinoza é vasto e complexo, tendo influenciado profundamente diversos campos do pensamento ocidental, embora essa influência tenha frequentemente ocorrido de forma subterrânea devido à reputação de ateísmo e heresia associada a seu nome durante séculos.",
        "No século XVIII, a filosofia de Spinoza foi central para o desenvolvimento do Iluminismo radical, especialmente através da 'controvérsia panteísta' na Alemanha. Pensadores como Lessing e Herder encontraram inspiração em suas ideias, enquanto a expressão 'Hen kai Pan' (Um e Tudo) tornou-se um lema para os românticos alemães influenciados pelo spinozismo.",
        "O idealismo alemão, especialmente em Hegel, incorporou elementos da filosofia de Spinoza, particularmente sua visão monista e sua concepção de Deus como imanente à natureza. Schelling chegou a declarar que 'ou Spinoza ou nenhuma filosofia'.",
        "No século XIX, Spinoza foi redescoberto e reinterpretado por pensadores como Nietzsche, que admirava sua crítica à moral tradicional e sua afirmação da vida, e Marx, que encontrou em seu materialismo e determinismo bases para sua própria filosofia.",
        "No século XX, filósofos como Gilles Deleuze e Antonio Negri desenvolveram leituras inovadoras de Spinoza, enfatizando aspectos de sua filosofia como a teoria dos afetos, o conceito de potência e suas implicações políticas. Deleuze viu em Spinoza um 'príncipe dos filósofos' e um pensador da imanência radical.",
        "Na ciência contemporânea, o monismo de Spinoza e sua rejeição do dualismo mente-corpo encontram paralelos em abordagens naturalistas da consciência. Neurocientistas como Antonio Damasio têm encontrado na teoria dos afetos de Spinoza intuições relevantes para a compreensão das emoções.",
        "Na política, o pensamento de Spinoza continua a inspirar reflexões sobre democracia, liberdade de expressão e tolerância. Sua defesa da liberdade de pensamento no Tratado Teológico-Político é considerada uma contribuição fundamental para o desenvolvimento das ideias liberais e democráticas.",
        "Apesar de ter sido considerado um pensador perigoso e herético em sua época, hoje Spinoza é reconhecido como um dos mais originais e profundos filósofos da tradição ocidental, cuja obra continua a oferecer recursos para pensar questões contemporâneas em metafísica, ética, política e psicologia."
      ],
      quotes: [
        {
          text: "Não rir, não lamentar, não detestar, mas compreender.",
          source: "Tratado Político"
        },
        {
          text: "A felicidade não é o prêmio da virtude, mas a própria virtude.",
          source: "Ética, Parte V"
        },
        {
          text: "Todas as coisas excelentes são tão difíceis quanto raras.",
          source: "Ética, Parte V, Proposição 42"
        },
        {
          text: "Ninguém sabe o que pode um corpo.",
          source: "Ética, Parte III"
        },
        {
          text: "O desejo é a própria essência do homem.",
          source: "Ética, Parte III, Proposição 9"
        }
      ],
      influencedBy: [
        { name: "Descartes", href: "/areas-tematicas/filosofia-moderna/descartes" },
        { name: "Maimônides", href: "/areas-tematicas/filosofia-medieval/maimonides" },
        { name: "Hobbes", href: "/areas-tematicas/filosofia-moderna/hobbes" },
        { name: "Giordano Bruno", href: "/areas-tematicas/filosofia-moderna/bruno" }
      ],
      influenced: [
        { name: "Hegel", href: "/areas-tematicas/filosofia-moderna/hegel" },
        { name: "Nietzsche", href: "/areas-tematicas/filosofia-contemporanea/nietzsche" },
        { name: "Einstein", href: "/areas-tematicas/ciencia/einstein" },
        { name: "Deleuze", href: "/areas-tematicas/filosofia-contemporanea/deleuze" }
      ],
      relatedResources: [
        {
          title: "A Ética de Spinoza: Uma Introdução",
          type: "Texto",
          buttonText: "Ler",
          href: "/recursos-didaticos/conteudo/etica-spinoza"
        },
        {
          title: "Quiz sobre Spinoza",
          type: "Atividade Interativa",
          buttonText: "Iniciar Quiz",
          href: "/atividades-interativas/quizzes/spinoza"
        },
        {
          title: "Mapa Conceitual: Sistema de Spinoza",
          type: "Mapa Mental",
          buttonText: "Visualizar",
          href: "/recursos-didaticos/mapas/sistema-spinoza"
        },
        {
          title: "Fórum: Spinoza e o Monismo",
          type: "Discussão",
          buttonText: "Participar",
          href: "/atividades-interativas/forum/spinoza"
        },
        {
          title: "HQ: A Vida de Spinoza",
          type: "História em Quadrinhos",
          buttonText: "Visualizar",
          href: "/recursos-didaticos/hq/spinoza"
        },
        {
          title: "Modo de Spinoza",
          type: "Jogo Filosófico",
          buttonText: "Jogar",
          href: "/atividades-interativas/jogos/modo-spinoza"
        }
      ]
    },
    // Adicione dados para outros filósofos conforme necessário
  };

  // Retorna os dados do filósofo solicitado ou um objeto padrão se não encontrar
  return filosofosData[slug] || {
    name: "Filósofo",
    shortDescription: "Descrição breve do filósofo.",
    period: "Período",
    birth: "Data de nascimento",
    death: "Data de morte",
    nationality: "Nacionalidade",
    school: "Corrente filosófica",
    mainWorks: ["Obra 1", "Obra 2"],
    areaLink: {
      label: "Voltar",
      href: "/"
    },
    biography: ["Biografia não disponível."],
    philosophy: ["Pensamento filosófico não disponível."],
    keyConcepts: [],
    works: [],
    legacy: ["Legado não disponível."],
    relatedResources: []
  };
}
