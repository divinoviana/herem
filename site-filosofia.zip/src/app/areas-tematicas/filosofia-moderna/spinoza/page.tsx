import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Link from "next/link";

export default function SpinozaPage() {
  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="filosofia-hero">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/80 to-secondary/80 opacity-90"></div>
        <div className="container relative z-10 mx-auto px-4 py-24 text-center">
          <h1 className="mb-6 text-4xl font-bold md:text-5xl lg:text-6xl">
            Baruch Spinoza
          </h1>
          <p className="mx-auto mb-8 max-w-3xl text-lg md:text-xl">
            Explore o pensamento de um dos mais importantes filósofos racionalistas do século XVII, 
            cujas ideias sobre Deus, natureza, mente e ética continuam relevantes até hoje.
          </p>
        </div>
      </section>

      {/* Conteúdo Principal */}
      <section className="filosofia-section">
        <div className="filosofia-container">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            {/* Sidebar com Biografia */}
            <div className="md:col-span-1">
              <Card className="filosofia-card sticky top-20">
                <CardHeader>
                  <CardTitle>Baruch Spinoza (1632-1677)</CardTitle>
                  <CardDescription>Filósofo racionalista holandês</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="mb-4 overflow-hidden rounded-md">
                    <div className="h-48 w-full bg-muted"></div>
                  </div>
                  <h3 className="mb-2 text-lg font-semibold">Biografia</h3>
                  <p className="mb-4 text-sm text-muted-foreground">
                    Nascido em Amsterdã em uma família de judeus portugueses, Spinoza foi excomungado da comunidade judaica aos 23 anos por suas visões heterodoxas. 
                    Viveu modestamente como polidor de lentes, dedicando-se à filosofia. Sua obra-prima, "Ética", foi publicada postumamente em 1677.
                  </p>
                  <h3 className="mb-2 text-lg font-semibold">Obras Principais</h3>
                  <ul className="list-disc pl-5 text-sm text-muted-foreground">
                    <li>Ética (1677)</li>
                    <li>Tratado Teológico-Político (1670)</li>
                    <li>Tratado Político (inacabado)</li>
                    <li>Tratado da Reforma do Entendimento</li>
                  </ul>
                </CardContent>
                <CardFooter>
                  <Button asChild variant="outline" className="w-full">
                    <Link href="/recursos-didaticos/biografias/spinoza">Biografia Completa</Link>
                  </Button>
                </CardFooter>
              </Card>
            </div>

            {/* Conteúdo Principal */}
            <div className="md:col-span-2">
              <Tabs defaultValue="pensamento" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="pensamento">Pensamento</TabsTrigger>
                  <TabsTrigger value="conceitos">Conceitos-Chave</TabsTrigger>
                  <TabsTrigger value="citacoes">Citações</TabsTrigger>
                  <TabsTrigger value="recursos">Recursos</TabsTrigger>
                </TabsList>
                
                {/* Pensamento */}
                <TabsContent value="pensamento" className="mt-6">
                  <h2 className="filosofia-subheading">O Pensamento de Spinoza</h2>
                  <div className="space-y-4">
                    <p>
                      Spinoza desenvolveu um sistema filosófico monista e determinista, rejeitando o dualismo cartesiano e propondo uma visão de Deus como substância infinita idêntica à Natureza. Seu pensamento é marcado por um racionalismo rigoroso e uma ética baseada na compreensão das leis naturais.
                    </p>
                    
                    <h3 className="text-xl font-semibold text-primary">Deus sive Natura (Deus ou Natureza)</h3>
                    <p>
                      Para Spinoza, Deus e a Natureza são a mesma coisa: uma única substância infinita com infinitos atributos. Esta visão, conhecida como panteísmo, rejeita a ideia de um Deus pessoal e transcendente, substituindo-a por uma concepção de Deus como a totalidade da realidade natural, governada por leis necessárias.
                    </p>
                    
                    <h3 className="text-xl font-semibold text-primary">Determinismo e Liberdade</h3>
                    <p>
                      Spinoza defendia um determinismo rigoroso: tudo o que acontece é necessário e não poderia ser diferente. No entanto, ele não via isso como negação da liberdade humana. Para ele, a verdadeira liberdade não consiste em escolhas arbitrárias, mas na compreensão das necessidades que nos determinam e na ação guiada pela razão.
                    </p>
                    
                    <h3 className="text-xl font-semibold text-primary">Teoria dos Afetos</h3>
                    <p>
                      Na Parte III da Ética, Spinoza desenvolve uma teoria dos afetos (emoções) que os trata como fenômenos naturais, não como falhas ou imperfeições. Ele analisa como as paixões nos afetam e como podemos, através do conhecimento, transformar paixões passivas em afetos ativos que aumentam nossa potência de agir.
                    </p>
                    
                    <h3 className="text-xl font-semibold text-primary">Ética e Beatitude</h3>
                    <p>
                      O objetivo final da filosofia de Spinoza é ético: alcançar a beatitude (felicidade suprema) através do conhecimento intuitivo de Deus/Natureza. Este conhecimento nos liberta das paixões negativas e nos permite compreender nosso lugar no universo, aceitando a necessidade de todas as coisas com uma espécie de "amor intelectual a Deus".
                    </p>
                  </div>
                </TabsContent>
                
                {/* Conceitos-Chave */}
                <TabsContent value="conceitos" className="mt-6">
                  <h2 className="filosofia-subheading">Conceitos-Chave de Spinoza</h2>
                  <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                    <Card className="filosofia-card">
                      <CardHeader>
                        <CardTitle>Substância</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground">
                          Para Spinoza, existe apenas uma substância infinita (Deus ou Natureza), que é causa de si mesma e existe necessariamente. Esta substância possui infinitos atributos, dos quais conhecemos apenas dois: pensamento e extensão.
                        </p>
                      </CardContent>
                    </Card>
                    
                    <Card className="filosofia-card">
                      <CardHeader>
                        <CardTitle>Atributos</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground">
                          Os atributos são as formas pelas quais percebemos a substância. Embora a substância tenha infinitos atributos, os seres humanos só podem conhecer dois: o pensamento (mundo das ideias) e a extensão (mundo físico).
                        </p>
                      </CardContent>
                    </Card>
                    
                    <Card className="filosofia-card">
                      <CardHeader>
                        <CardTitle>Modos</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground">
                          Os modos são modificações ou afecções da substância. Todos os seres particulares (incluindo os humanos) são modos da substância divina, expressões finitas e determinadas de Deus/Natureza.
                        </p>
                      </CardContent>
                    </Card>
                    
                    <Card className="filosofia-card">
                      <CardHeader>
                        <CardTitle>Conatus</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground">
                          O conatus é o esforço pelo qual cada coisa se esforça para perseverar em seu ser. É a essência atual de cada modo, seu impulso fundamental de autopreservação e aumento de potência.
                        </p>
                      </CardContent>
                    </Card>
                    
                    <Card className="filosofia-card">
                      <CardHeader>
                        <CardTitle>Afetos</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground">
                          Os afetos são as afecções do corpo que aumentam ou diminuem sua potência de agir, junto com as ideias dessas afecções. Spinoza identifica três afetos primários: alegria (aumento de potência), tristeza (diminuição de potência) e desejo.
                        </p>
                      </CardContent>
                    </Card>
                    
                    <Card className="filosofia-card">
                      <CardHeader>
                        <CardTitle>Amor Intellectualis Dei</CardTitle>
                      </CardHeader>
                      <CardContent>
                        <p className="text-muted-foreground">
                          O "amor intelectual a Deus" é o estado supremo da mente humana, alcançado quando compreendemos intuitivamente nossa relação com a totalidade da Natureza. É a forma mais elevada de conhecimento e a fonte da verdadeira beatitude.
                        </p>
                      </CardContent>
                    </Card>
                  </div>
                </TabsContent>
                
                {/* Citações */}
                <TabsContent value="citacoes" className="mt-6">
                  <h2 className="filosofia-subheading">Citações de Spinoza</h2>
                  <div className="space-y-6">
                    <blockquote className="border-l-4 border-primary bg-muted/30 p-4 italic">
                      "Não rir, não lamentar, não detestar, mas compreender."
                      <footer className="mt-2 text-right text-sm text-muted-foreground">— Tratado Político</footer>
                    </blockquote>
                    
                    <blockquote className="border-l-4 border-primary bg-muted/30 p-4 italic">
                      "A felicidade não é o prêmio da virtude, mas a própria virtude."
                      <footer className="mt-2 text-right text-sm text-muted-foreground">— Ética, Parte V</footer>
                    </blockquote>
                    
                    <blockquote className="border-l-4 border-primary bg-muted/30 p-4 italic">
                      "Todas as coisas excelentes são tão difíceis quanto raras."
                      <footer className="mt-2 text-right text-sm text-muted-foreground">— Ética, Parte V, Proposição 42</footer>
                    </blockquote>
                    
                    <blockquote className="border-l-4 border-primary bg-muted/30 p-4 italic">
                      "Ninguém sabe o que pode um corpo."
                      <footer className="mt-2 text-right text-sm text-muted-foreground">— Ética, Parte III</footer>
                    </blockquote>
                    
                    <blockquote className="border-l-4 border-primary bg-muted/30 p-4 italic">
                      "O desejo é a própria essência do homem."
                      <footer className="mt-2 text-right text-sm text-muted-foreground">— Ética, Parte III, Proposição 9</footer>
                    </blockquote>
                  </div>
                </TabsContent>
                
                {/* Recursos */}
                <TabsContent value="recursos" className="mt-6">
                  <h2 className="filosofia-subheading">Recursos sobre Spinoza</h2>
                  <div className="space-y-6">
                    <div>
                      <h3 className="mb-2 text-xl font-semibold text-primary">Leituras Recomendadas</h3>
                      <ul className="list-disc pl-5 text-muted-foreground">
                        <li>Ética - Baruch Spinoza (edição comentada)</li>
                        <li>Spinoza: Uma Introdução - Stuart Hampshire</li>
                        <li>Espinosa: Filosofia Prática - Gilles Deleuze</li>
                        <li>Spinoza e o Problema da Expressão - Gilles Deleuze</li>
                        <li>A Anomalia Selvagem - Antonio Negri</li>
                      </ul>
                    </div>
                    
                    <div>
                      <h3 className="mb-2 text-xl font-semibold text-primary">Materiais Didáticos</h3>
                      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                        <Card className="filosofia-card">
                          <CardHeader>
                            <CardTitle>Mapa Conceitual</CardTitle>
                            <CardDescription>Sistema filosófico de Spinoza</CardDescription>
                          </CardHeader>
                          <CardFooter>
                            <Button asChild variant="outline" className="w-full">
                              <Link href="/recursos-didaticos/mapas/spinoza">Visualizar</Link>
                            </Button>
                          </CardFooter>
                        </Card>
                        
                        <Card className="filosofia-card">
                          <CardHeader>
                            <CardTitle>HQ Filosófica</CardTitle>
                            <CardDescription>A vida e o pensamento de Spinoza em quadrinhos</CardDescription>
                          </CardHeader>
                          <CardFooter>
                            <Button asChild variant="outline" className="w-full">
                              <Link href="/recursos-didaticos/hq/spinoza">Visualizar</Link>
                            </Button>
                          </CardFooter>
                        </Card>
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="mb-2 text-xl font-semibold text-primary">Atividades</h3>
                      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                        <Card className="filosofia-card">
                          <CardHeader>
                            <CardTitle>Quiz sobre Spinoza</CardTitle>
                            <CardDescription>Teste seus conhecimentos</CardDescription>
                          </CardHeader>
                          <CardFooter>
                            <Button asChild className="w-full filosofia-button-secondary">
                              <Link href="/atividades-interativas/quizzes/spinoza">Iniciar Quiz</Link>
                            </Button>
                          </CardFooter>
                        </Card>
                        
                        <Card className="filosofia-card">
                          <CardHeader>
                            <CardTitle>Fórum de Discussão</CardTitle>
                            <CardDescription>Debata sobre o pensamento spinozista</CardDescription>
                          </CardHeader>
                          <CardFooter>
                            <Button asChild className="w-full filosofia-button-secondary">
                              <Link href="/atividades-interativas/forum/spinoza">Participar</Link>
                            </Button>
                          </CardFooter>
                        </Card>
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
