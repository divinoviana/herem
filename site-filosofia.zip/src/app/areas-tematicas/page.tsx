import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";

export default function AreasPage() {
  return (
    <MainLayout>
      <section className="filosofia-hero bg-primary">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/80 to-secondary/80 opacity-90"></div>
        <div className="container relative z-10 mx-auto px-4 py-16 text-center">
          <h1 className="mb-6 text-4xl font-bold md:text-5xl lg:text-6xl">
            Áreas Temáticas
          </h1>
          <p className="mx-auto mb-8 max-w-3xl text-lg md:text-xl">
            Explore os principais campos da filosofia e conheça as ideias que moldaram o pensamento humano ao longo da história.
          </p>
        </div>
      </section>

      <section className="filosofia-section">
        <div className="filosofia-container">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Filosofia Antiga</CardTitle>
                <CardDescription>Dos pré-socráticos ao helenismo</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Explore o nascimento do pensamento filosófico ocidental na Grécia Antiga, com pensadores como Sócrates, Platão e Aristóteles.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/areas-tematicas/filosofia-antiga">
                    Explorar
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Filosofia Medieval</CardTitle>
                <CardDescription>Fé e razão na Idade Média</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Conheça o pensamento filosófico medieval, marcado pela relação entre fé e razão, com pensadores como Agostinho e Tomás de Aquino.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/areas-tematicas/filosofia-medieval">
                    Explorar
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Filosofia Moderna</CardTitle>
                <CardDescription>Racionalismo, empirismo e iluminismo</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Descubra as transformações do pensamento filosófico na modernidade, com destaque para Descartes, Spinoza, Locke, Hume e Kant.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/areas-tematicas/filosofia-moderna">
                    Explorar
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Filosofia Contemporânea</CardTitle>
                <CardDescription>Correntes filosóficas atuais</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Explore as diversas correntes filosóficas dos séculos XIX, XX e XXI, como existencialismo, fenomenologia, pragmatismo e filosofia analítica.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/areas-tematicas/filosofia-contemporanea">
                    Explorar
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Filosofia Brasileira</CardTitle>
                <CardDescription>O pensamento filosófico no Brasil</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Conheça os principais pensadores e correntes filosóficas desenvolvidas no Brasil, desde o período colonial até a contemporaneidade.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/areas-tematicas/filosofia-brasileira">
                    Explorar
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Ética e Política</CardTitle>
                <CardDescription>Reflexões sobre moral e sociedade</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Explore teorias éticas e políticas que buscam compreender questões sobre o bem, a justiça, a liberdade e a organização da sociedade.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/areas-tematicas/etica-politica">
                    Explorar
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Lógica e Conhecimento</CardTitle>
                <CardDescription>Fundamentos do raciocínio e da epistemologia</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Descubra os princípios da lógica e as teorias sobre a natureza, as fontes e os limites do conhecimento humano.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/areas-tematicas/logica-conhecimento">
                    Explorar
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Estética e Arte</CardTitle>
                <CardDescription>Filosofia da beleza e da criação artística</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Explore reflexões filosóficas sobre a beleza, a arte, a criatividade e a experiência estética ao longo da história.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/areas-tematicas/estetica-arte">
                    Explorar
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>

      <section className="filosofia-section bg-muted/30">
        <div className="filosofia-container">
          <h2 className="filosofia-heading text-center">Destaque: Spinoza</h2>
          <p className="mx-auto mb-12 max-w-3xl text-center text-muted-foreground">
            Conheça o pensamento de Baruch Spinoza, um dos mais originais filósofos da modernidade.
          </p>
          
          <div className="mx-auto max-w-4xl">
            <Card className="filosofia-card">
              <div className="h-64 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Baruch Spinoza (1632-1677)</CardTitle>
                <CardDescription>
                  Filósofo racionalista holandês de origem judaica sefardita
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="mb-4">
                  Spinoza desenvolveu um sistema filosófico monista e determinista, identificando Deus com a Natureza. 
                  Sua obra-prima, a Ética, escrita segundo o método geométrico, apresenta uma visão revolucionária 
                  sobre metafísica, epistemologia, psicologia e ética.
                </p>
                <p className="mb-4">
                  Excomungado da comunidade judaica de Amsterdã por suas ideias heterodoxas, Spinoza viveu modestamente 
                  como polidor de lentes, dedicando-se à filosofia com total independência intelectual.
                </p>
                <p>
                  Seu pensamento influenciou profundamente filósofos posteriores e continua relevante para discussões 
                  contemporâneas em diversos campos, da metafísica à política, da psicologia à neurociência.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/areas-tematicas/filosofia-moderna/spinoza">
                    Conhecer Spinoza
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
