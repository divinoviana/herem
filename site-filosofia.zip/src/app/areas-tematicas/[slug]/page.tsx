import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import Link from "next/link";

interface AreaTematicaPageProps {
  params: {
    slug: string;
  };
}

export default function AreaTematicaPage({ params }: AreaTematicaPageProps) {
  // Dados que seriam carregados dinamicamente com base no slug
  const areaData = getAreaData(params.slug);

  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="filosofia-hero">
        <div className="absolute inset-0 bg-gradient-to-r from-primary/80 to-secondary/80 opacity-90"></div>
        <div className="container relative z-10 mx-auto px-4 py-24 text-center">
          <h1 className="mb-6 text-4xl font-bold md:text-5xl lg:text-6xl">
            {areaData.title}
          </h1>
          <p className="mx-auto mb-8 max-w-3xl text-lg md:text-xl">
            {areaData.description}
          </p>
        </div>
      </section>

      {/* Conteúdo Principal */}
      <section className="filosofia-section">
        <div className="filosofia-container">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-3">
            {/* Sidebar */}
            <div className="md:col-span-1">
              <Card className="filosofia-card sticky top-20">
                <CardHeader>
                  <CardTitle>Navegação</CardTitle>
                  <CardDescription>Explore esta área temática</CardDescription>
                </CardHeader>
                <CardContent>
                  <nav className="space-y-1">
                    {areaData.navigation.map((item, index) => (
                      <Link 
                        key={index} 
                        href={item.href}
                        className="block rounded-md px-3 py-2 text-sm hover:bg-muted"
                      >
                        {item.label}
                      </Link>
                    ))}
                  </nav>
                </CardContent>
                <CardFooter>
                  <Button asChild variant="outline" className="w-full">
                    <Link href="/areas-tematicas">
                      Voltar para Áreas Temáticas
                    </Link>
                  </Button>
                </CardFooter>
              </Card>
            </div>

            {/* Conteúdo Principal */}
            <div className="md:col-span-2">
              <Tabs defaultValue="visao-geral" className="w-full">
                <TabsList className="grid w-full grid-cols-4">
                  <TabsTrigger value="visao-geral">Visão Geral</TabsTrigger>
                  <TabsTrigger value="pensadores">Pensadores</TabsTrigger>
                  <TabsTrigger value="conceitos">Conceitos</TabsTrigger>
                  <TabsTrigger value="recursos">Recursos</TabsTrigger>
                </TabsList>
                
                {/* Visão Geral */}
                <TabsContent value="visao-geral" className="mt-6">
                  <h2 className="filosofia-subheading">Sobre {areaData.title}</h2>
                  <div className="space-y-4">
                    {areaData.overview.map((paragraph, index) => (
                      <p key={index}>{paragraph}</p>
                    ))}
                  </div>
                  
                  {areaData.timelineTitle && (
                    <>
                      <h3 className="mt-8 text-xl font-semibold text-primary">{areaData.timelineTitle}</h3>
                      <div className="mt-4 space-y-4">
                        {areaData.timeline.map((item, index) => (
                          <div key={index} className="flex gap-4">
                            <div className="flex flex-col items-center">
                              <div className="h-6 w-6 rounded-full bg-primary text-center text-xs text-primary-foreground flex items-center justify-center">
                                {index + 1}
                              </div>
                              {index < areaData.timeline.length - 1 && (
                                <div className="h-full w-0.5 bg-border"></div>
                              )}
                            </div>
                            <div className="pb-6">
                              <h4 className="text-lg font-medium">{item.title}</h4>
                              <p className="text-sm text-muted-foreground">{item.period}</p>
                              <p className="mt-2">{item.description}</p>
                            </div>
                          </div>
                        ))}
                      </div>
                    </>
                  )}
                </TabsContent>
                
                {/* Pensadores */}
                <TabsContent value="pensadores" className="mt-6">
                  <h2 className="filosofia-subheading">Principais Pensadores</h2>
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    {areaData.thinkers.map((thinker, index) => (
                      <Card key={index} className="filosofia-card">
                        <CardHeader>
                          <CardTitle>{thinker.name}</CardTitle>
                          <CardDescription>{thinker.period}</CardDescription>
                        </CardHeader>
                        <CardContent>
                          <p className="text-sm text-muted-foreground">{thinker.description}</p>
                        </CardContent>
                        <CardFooter>
                          <Button asChild variant="outline" className="w-full">
                            <Link href={thinker.href}>
                              Saiba Mais
                            </Link>
                          </Button>
                        </CardFooter>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
                
                {/* Conceitos */}
                <TabsContent value="conceitos" className="mt-6">
                  <h2 className="filosofia-subheading">Conceitos-Chave</h2>
                  <div className="grid grid-cols-1 gap-4 md:grid-cols-2">
                    {areaData.concepts.map((concept, index) => (
                      <Card key={index} className="filosofia-card">
                        <CardHeader>
                          <CardTitle>{concept.title}</CardTitle>
                        </CardHeader>
                        <CardContent>
                          <p className="text-muted-foreground">{concept.description}</p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </TabsContent>
                
                {/* Recursos */}
                <TabsContent value="recursos" className="mt-6">
                  <h2 className="filosofia-subheading">Recursos Didáticos</h2>
                  <div className="space-y-6">
                    <div>
                      <h3 className="mb-2 text-xl font-semibold text-primary">Materiais de Estudo</h3>
                      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                        {areaData.resources.materials.map((material, index) => (
                          <Card key={index} className="filosofia-card">
                            <CardHeader>
                              <CardTitle>{material.title}</CardTitle>
                              <CardDescription>{material.type}</CardDescription>
                            </CardHeader>
                            <CardFooter>
                              <Button asChild variant="outline" className="w-full">
                                <Link href={material.href}>Acessar</Link>
                              </Button>
                            </CardFooter>
                          </Card>
                        ))}
                      </div>
                    </div>
                    
                    <div>
                      <h3 className="mb-2 text-xl font-semibold text-primary">Atividades</h3>
                      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                        {areaData.resources.activities.map((activity, index) => (
                          <Card key={index} className="filosofia-card">
                            <CardHeader>
                              <CardTitle>{activity.title}</CardTitle>
                              <CardDescription>{activity.type}</CardDescription>
                            </CardHeader>
                            <CardFooter>
                              <Button asChild className="w-full filosofia-button-secondary">
                                <Link href={activity.href}>{activity.buttonText}</Link>
                              </Button>
                            </CardFooter>
                          </Card>
                        ))}
                      </div>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}

// Função para obter dados da área temática com base no slug
function getAreaData(slug: string) {
  // Aqui você implementaria a lógica para buscar dados do backend
  // Por enquanto, retornamos dados de exemplo para a área "filosofia-antiga"
  
  const areasData: Record<string, any> = {
    "filosofia-antiga": {
      title: "Filosofia Antiga",
      description: "Explore o nascimento do pensamento filosófico ocidental na Grécia Antiga, dos pré-socráticos ao período helenístico.",
      navigation: [
        { label: "Visão Geral", href: "/areas-tematicas/filosofia-antiga" },
        { label: "Pré-Socráticos", href: "/areas-tematicas/filosofia-antiga/pre-socraticos" },
        { label: "Sócrates", href: "/areas-tematicas/filosofia-antiga/socrates" },
        { label: "Platão", href: "/areas-tematicas/filosofia-antiga/platao" },
        { label: "Aristóteles", href: "/areas-tematicas/filosofia-antiga/aristoteles" },
        { label: "Escolas Helenísticas", href: "/areas-tematicas/filosofia-antiga/helenismo" },
      ],
      overview: [
        "A Filosofia Antiga marca o nascimento do pensamento filosófico ocidental, tendo seu berço na Grécia Antiga por volta do século VI a.C. Este período é caracterizado pela transição do pensamento mítico para o pensamento racional, onde os primeiros filósofos buscavam explicações naturais para os fenômenos do mundo, em vez de atribuí-los à vontade dos deuses.",
        "Os primeiros filósofos, conhecidos como pré-socráticos, estavam principalmente interessados em questões cosmológicas e na busca pelo princípio fundamental (arché) que constituiria todas as coisas. Figuras como Tales, Anaximandro, Heráclito e Parmênides desenvolveram as primeiras teorias sobre a natureza da realidade.",
        "Com Sócrates, houve uma mudança significativa no foco da filosofia, que passou das questões cosmológicas para questões éticas e epistemológicas. Seu método dialético de questionamento (maiêutica) e sua busca pela definição de conceitos morais influenciaram profundamente o desenvolvimento posterior da filosofia.",
        "Platão, discípulo de Sócrates, expandiu o pensamento de seu mestre e desenvolveu uma metafísica complexa baseada na teoria das Formas ou Ideias. Sua obra abrange questões de ética, política, epistemologia e metafísica, e foi transmitida através de diálogos que frequentemente apresentam Sócrates como personagem principal.",
        "Aristóteles, aluno de Platão, desenvolveu um sistema filosófico abrangente que incluía lógica, física, metafísica, ética, política e estética. Sua abordagem empírica e sistemática contrastava com o idealismo platônico, e sua influência se estendeu por séculos, tanto no mundo ocidental quanto no mundo árabe.",
        "O período helenístico, após a morte de Alexandre o Grande, viu o surgimento de escolas filosóficas como o Estoicismo, o Epicurismo, o Ceticismo e o Neoplatonismo, cada uma oferecendo diferentes visões sobre como alcançar a felicidade e a tranquilidade em um mundo em mudança."
      ],
      timelineTitle: "Linha do Tempo da Filosofia Antiga",
      timeline: [
        {
          title: "Período Pré-Socrático",
          period: "c. 600-450 a.C.",
          description: "Primeiros filósofos focados em explicações naturais para o cosmos. Principais figuras: Tales, Anaximandro, Heráclito, Parmênides, Empédocles, Demócrito."
        },
        {
          title: "Período Socrático",
          period: "c. 450-399 a.C.",
          description: "Mudança para questões éticas e epistemológicas. Sócrates desenvolve o método dialético e busca definições de conceitos morais."
        },
        {
          title: "Período Platônico",
          period: "c. 399-347 a.C.",
          description: "Desenvolvimento da teoria das Formas e fundação da Academia. Platão escreve diálogos abordando metafísica, epistemologia, ética e política."
        },
        {
          title: "Período Aristotélico",
          period: "c. 347-322 a.C.",
          description: "Desenvolvimento de um sistema filosófico abrangente. Aristóteles funda o Liceu e produz obras sobre lógica, física, metafísica, ética e política."
        },
        {
          title: "Período Helenístico",
          period: "c. 322-30 a.C.",
          description: "Surgimento de escolas como Estoicismo, Epicurismo e Ceticismo, focadas em como viver bem em um mundo em mudança."
        },
        {
          title: "Período Romano e Neoplatônico",
          period: "c. 30 a.C.-529 d.C.",
          description: "Adaptação da filosofia grega ao mundo romano e desenvolvimento do Neoplatonismo. Figuras importantes: Cícero, Sêneca, Epicteto, Marco Aurélio, Plotino."
        }
      ],
      thinkers: [
        {
          name: "Sócrates",
          period: "469-399 a.C.",
          description: "Conhecido por seu método dialético de questionamento e sua busca pela definição de conceitos morais. Não deixou escritos, sendo conhecido através dos relatos de seus discípulos, principalmente Platão.",
          href: "/areas-tematicas/filosofia-antiga/socrates"
        },
        {
          name: "Platão",
          period: "428/427-348/347 a.C.",
          description: "Fundador da Academia e autor de diálogos filosóficos. Desenvolveu a teoria das Formas e abordou questões de metafísica, epistemologia, ética e política.",
          href: "/areas-tematicas/filosofia-antiga/platao"
        },
        {
          name: "Aristóteles",
          period: "384-322 a.C.",
          description: "Fundador do Liceu e criador de um sistema filosófico abrangente. Suas obras abarcam lógica, física, metafísica, ética, política e estética.",
          href: "/areas-tematicas/filosofia-antiga/aristoteles"
        },
        {
          name: "Epicuro",
          period: "341-270 a.C.",
          description: "Fundador do Epicurismo, que busca a felicidade através do prazer moderado e da ausência de dor e perturbação mental.",
          href: "/areas-tematicas/filosofia-antiga/epicuro"
        }
      ],
      concepts: [
        {
          title: "Arché",
          description: "Princípio fundamental ou elemento primordial que constitui todas as coisas, buscado pelos filósofos pré-socráticos."
        },
        {
          title: "Maiêutica",
          description: "Método socrático de questionamento que visa 'dar à luz' o conhecimento já presente na mente do interlocutor."
        },
        {
          title: "Teoria das Formas",
          description: "Concepção platônica de que existe um reino de Formas ou Ideias perfeitas e eternas, das quais os objetos do mundo sensível são meras cópias imperfeitas."
        },
        {
          title: "Hilemorfismo",
          description: "Teoria aristotélica de que todas as substâncias são compostas de matéria (hyle) e forma (morphe)."
        },
        {
          title: "Eudaimonia",
          description: "Conceito grego de felicidade ou bem-estar, entendido como florescimento humano e vida virtuosa."
        },
        {
          title: "Ataraxia",
          description: "Estado de tranquilidade e ausência de perturbação mental, buscado por epicuristas e céticos."
        }
      ],
      resources: {
        materials: [
          {
            title: "Mapa Mental: Filosofia Antiga",
            type: "Mapa Conceitual",
            href: "/recursos-didaticos/mapas/filosofia-antiga"
          },
          {
            title: "HQ: A República de Platão",
            type: "História em Quadrinhos",
            href: "/recursos-didaticos/hq/republica-platao"
          },
          {
            title: "Glossário de Termos da Filosofia Antiga",
            type: "Glossário",
            href: "/recursos-didaticos/glossario/filosofia-antiga"
          },
          {
            title: "Resumo: Ética a Nicômaco",
            type: "Resumo",
            href: "/recursos-didaticos/resumos/etica-nicomaco"
          }
        ],
        activities: [
          {
            title: "Quiz sobre Filosofia Antiga",
            type: "Quiz Interativo",
            buttonText: "Iniciar Quiz",
            href: "/atividades-interativas/quizzes/filosofia-antiga"
          },
          {
            title: "Fórum: Alegoria da Caverna",
            type: "Discussão",
            buttonText: "Participar",
            href: "/atividades-interativas/forum/alegoria-caverna"
          }
        ]
      }
    },
    "filosofia-moderna": {
      title: "Filosofia Moderna",
      description: "Explore o pensamento filosófico do Renascimento ao Iluminismo, com foco no racionalismo, empirismo e idealismo.",
      navigation: [
        { label: "Visão Geral", href: "/areas-tematicas/filosofia-moderna" },
        { label: "Racionalismo", href: "/areas-tematicas/filosofia-moderna/racionalismo" },
        { label: "Empirismo", href: "/areas-tematicas/filosofia-moderna/empirismo" },
        { label: "Iluminismo", href: "/areas-tematicas/filosofia-moderna/iluminismo" },
        { label: "Idealismo Alemão", href: "/areas-tematicas/filosofia-moderna/idealismo" },
        { label: "Spinoza", href: "/areas-tematicas/filosofia-moderna/spinoza" },
      ],
      overview: [
        "A Filosofia Moderna abrange aproximadamente o período do século XVI ao final do século XVIII, marcado por profundas transformações no pensamento europeu. Este período testemunhou o surgimento da ciência moderna, a Reforma Protestante, o desenvolvimento do capitalismo e a formação dos estados nacionais, eventos que influenciaram significativamente o pensamento filosófico.",
        "Um dos marcos iniciais da Filosofia Moderna é o trabalho de René Descartes, cujo método da dúvida sistemática e o famoso 'Penso, logo existo' estabeleceram as bases do racionalismo. Esta corrente, desenvolvida também por filósofos como Spinoza e Leibniz, enfatizava o papel da razão como fonte primária de conhecimento.",
        "Em contraste, o empirismo britânico, representado por Locke, Berkeley e Hume, defendia que todo conhecimento deriva da experiência sensorial. O debate entre racionalistas e empiristas sobre a natureza e os limites do conhecimento humano foi um dos temas centrais da filosofia moderna.",
        "O Iluminismo, movimento intelectual do século XVIII, enfatizou o uso da razão, da ciência e do debate intelectual para questionar tradições e reformar a sociedade. Filósofos iluministas como Voltaire, Rousseau e Montesquieu desenvolveram ideias sobre liberdade, igualdade, tolerância e separação entre Igreja e Estado que influenciaram revoluções políticas.",
        "Immanuel Kant, em resposta ao debate entre racionalismo e empirismo, desenvolveu sua filosofia crítica, argumentando que o conhecimento resulta tanto da experiência sensorial quanto de estruturas a priori da mente. Sua obra influenciou profundamente o desenvolvimento posterior da filosofia, especialmente o idealismo alemão.",
        "O período moderno também viu importantes desenvolvimentos na filosofia política, com teóricos do contrato social como Hobbes, Locke e Rousseau propondo diferentes visões sobre a origem e legitimidade do poder político, estabelecendo as bases para conceitos modernos de direitos, soberania e democracia."
      ],
      timelineTitle: "Linha do Tempo da Filosofia Moderna",
      timeline: [
        {
          title: "Renascimento e Humanismo",
          period: "c. 1400-1600",
          description: "Redescoberta dos clássicos greco-romanos e ênfase na dignidade humana. Figuras importantes: Erasmo, Montaigne, Maquiavel."
        },
        {
          title: "Racionalismo Continental",
          period: "c. 1600-1750",
          description: "Ênfase na razão como fonte primária de conhecimento. Principais filósofos: Descartes, Spinoza, Leibniz."
        },
        {
          title: "Empirismo Britânico",
          period: "c. 1650-1780",
          description: "Ênfase na experiência sensorial como fonte de conhecimento. Principais filósofos: Locke, Berkeley, Hume."
        },
        {
          title: "Iluminismo",
          period: "c. 1715-1789",
          description: "Movimento intelectual enfatizando razão, ciência e reforma social. Figuras importantes: Voltaire, Rousseau, Montesquieu, Diderot."
        },
        {
          title: "Filosofia Crítica de Kant",
          period: "c. 1780-1800",
          description: "Síntese entre racionalismo e empirismo, desenvolvendo a filosofia transcendental. Obras principais: Crítica da Razão Pura, Crítica da Razão Prática."
        },
        {
          title: "Idealismo Alemão",
          period: "c. 1790-1830",
          description: "Desenvolvimento das ideias kantianas em sistemas metafísicos abrangentes. Principais filósofos: Fichte, Schelling, Hegel."
        }
      ],
      thinkers: [
        {
          name: "René Descartes",
          period: "1596-1650",
          description: "Considerado o pai da filosofia moderna. Desenvolveu o método da dúvida sistemática e estabeleceu as bases do racionalismo com seu 'Cogito, ergo sum' (Penso, logo existo).",
          href: "/areas-tematicas/filosofia-moderna/descartes"
        },
        {
          name: "Baruch Spinoza",
          period: "1632-1677",
          description: "Desenvolveu um sistema filosófico monista e determinista, identificando Deus com a Natureza. Sua Ética, escrita em estilo geométrico, aborda metafísica, epistemologia e ética.",
          href: "/areas-tematicas/filosofia-moderna/spinoza"
        },
        {
          name: "John Locke",
          period: "1632-1704",
          description: "Empirista que defendia que a mente é uma 'tábula rasa' preenchida pela experiência. Influente em epistemologia, política e teoria da educação.",
          href: "/areas-tematicas/filosofia-moderna/locke"
        },
        {
          name: "Immanuel Kant",
          period: "1724-1804",
          description: "Desenvolveu a filosofia crítica, sintetizando racionalismo e empirismo. Sua obra revolucionou a epistemologia, a ética e a estética.",
          href: "/areas-tematicas/filosofia-moderna/kant"
        }
      ],
      concepts: [
        {
          title: "Racionalismo",
          description: "Corrente filosófica que enfatiza o papel da razão como fonte primária de conhecimento, independente da experiência sensorial."
        },
        {
          title: "Empirismo",
          description: "Corrente filosófica que defende que todo conhecimento deriva da experiência sensorial, rejeitando ideias inatas."
        },
        {
          title: "Dualismo Cartesiano",
          description: "Concepção de Descartes de que mente (res cogitans) e corpo (res extensa) são substâncias distintas e separadas."
        },
        {
          title: "Monismo",
          description: "Visão filosófica, defendida por Spinoza, de que existe apenas uma substância (Deus ou Natureza) da qual todas as coisas são modos ou afecções."
        },
        {
          title: "Contrato Social",
          description: "Teoria política que explica a origem e legitimidade do Estado e da autoridade política como resultado de um acordo entre indivíduos."
        },
        {
          title: "Imperativo Categórico",
          description: "Princípio ético kantiano que determina que devemos agir apenas segundo máximas que possam se tornar leis universais."
        }
      ],
      resources: {
        materials: [
          {
            title: "Mapa Mental: Racionalismo vs. Empirismo",
            type: "Mapa Conceitual",
            href: "/recursos-didaticos/mapas/racionalismo-empirismo"
          },
          {
            title: "HQ: A Vida de Spinoza",
            type: "História em Quadrinhos",
            href: "/recursos-didaticos/hq/spinoza"
          },
          {
            title: "Resumo: Crítica da Razão Pura",
            type: "Resumo",
            href: "/recursos-didaticos/resumos/critica-razao-pura"
          },
          {
            title: "Infográfico: Iluminismo",
            type: "Infográfico",
            href: "/recursos-didaticos/infograficos/iluminismo"
          }
        ],
        activities: [
          {
            title: "Quiz sobre Filosofia Moderna",
            type: "Quiz Interativo",
            buttonText: "Iniciar Quiz",
            href: "/atividades-interativas/quizzes/filosofia-moderna"
          },
          {
            title: "Fórum: Spinoza e o Monismo",
            type: "Discussão",
            buttonText: "Participar",
            href: "/atividades-interativas/forum/spinoza"
          }
        ]
      }
    },
    // Adicione dados para outras áreas temáticas conforme necessário
  };

  // Retorna os dados da área solicitada ou um objeto padrão se não encontrar
  return areasData[slug] || {
    title: "Área Temática",
    description: "Descrição da área temática.",
    navigation: [],
    overview: ["Conteúdo não disponível para esta área temática."],
    thinkers: [],
    concepts: [],
    resources: {
      materials: [],
      activities: []
    }
  };
}
