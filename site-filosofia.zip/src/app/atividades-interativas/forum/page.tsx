import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import Link from "next/link";

export default function ForumPage() {
  return (
    <MainLayout>
      <section className="filosofia-hero bg-secondary">
        <div className="absolute inset-0 bg-gradient-to-r from-secondary/80 to-primary/80 opacity-90"></div>
        <div className="container relative z-10 mx-auto px-4 py-16 text-center">
          <h1 className="mb-6 text-4xl font-bold md:text-5xl lg:text-6xl">
            Fórum de Discussão Filosófica
          </h1>
          <p className="mx-auto mb-8 max-w-3xl text-lg md:text-xl">
            Participe de debates filosóficos, compartilhe suas ideias e aprenda com outros estudantes.
            Um espaço para reflexão coletiva e troca de conhecimentos.
          </p>
        </div>
      </section>

      <section className="filosofia-section">
        <div className="filosofia-container">
          <Tabs defaultValue="spinoza" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="spinoza">Spinoza</TabsTrigger>
              <TabsTrigger value="etica">Ética</TabsTrigger>
              <TabsTrigger value="politica">Filosofia Política</TabsTrigger>
              <TabsTrigger value="geral">Discussões Gerais</TabsTrigger>
            </TabsList>
            
            <TabsContent value="spinoza" className="mt-6">
              <ForumSpinoza />
            </TabsContent>
            
            <TabsContent value="etica" className="mt-6">
              <Card className="filosofia-card">
                <CardHeader>
                  <CardTitle>Fórum de Ética</CardTitle>
                  <CardDescription>Discussões sobre teorias éticas e dilemas morais</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-center text-muted-foreground">
                    Esta seção será implementada em breve. Aqui você poderá discutir sobre utilitarismo, 
                    deontologia, ética das virtudes e outros temas relacionados à filosofia moral.
                  </p>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="politica" className="mt-6">
              <Card className="filosofia-card">
                <CardHeader>
                  <CardTitle>Fórum de Filosofia Política</CardTitle>
                  <CardDescription>Debates sobre teorias políticas e questões sociais</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-center text-muted-foreground">
                    Esta seção será implementada em breve. Aqui você poderá discutir sobre contratualismo, 
                    liberalismo, marxismo e outros temas relacionados à filosofia política.
                  </p>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="geral" className="mt-6">
              <Card className="filosofia-card">
                <CardHeader>
                  <CardTitle>Discussões Gerais</CardTitle>
                  <CardDescription>Tópicos diversos de filosofia</CardDescription>
                </CardHeader>
                <CardContent>
                  <p className="text-center text-muted-foreground">
                    Esta seção será implementada em breve. Aqui você poderá discutir sobre qualquer tema 
                    filosófico que não se encaixe nas outras categorias.
                  </p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </section>
    </MainLayout>
  );
}

function ForumSpinoza() {
  return (
    <div className="space-y-6">
      <Card className="filosofia-card">
        <CardHeader>
          <CardTitle>Fórum de Discussão: Spinoza</CardTitle>
          <CardDescription>Debates sobre o pensamento spinozista</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="mb-6">
            <h3 className="mb-4 text-xl font-semibold">Criar Nova Discussão</h3>
            <div className="space-y-4">
              <div>
                <label htmlFor="topic-title" className="mb-2 block text-sm font-medium">
                  Título da Discussão
                </label>
                <Input id="topic-title" placeholder="Ex: A concepção de Deus em Spinoza" />
              </div>
              <div>
                <label htmlFor="topic-content" className="mb-2 block text-sm font-medium">
                  Conteúdo
                </label>
                <Textarea 
                  id="topic-content" 
                  placeholder="Compartilhe suas ideias, dúvidas ou reflexões sobre o tema..." 
                  className="min-h-[150px]"
                />
              </div>
              <Button className="filosofia-button-primary">Publicar Discussão</Button>
            </div>
          </div>
          
          <div>
            <h3 className="mb-4 text-xl font-semibold">Discussões Recentes</h3>
            <div className="space-y-4">
              {[
                {
                  id: 1,
                  title: "Monismo vs. Dualismo: A visão de Spinoza e Descartes",
                  author: "Prof. Silva",
                  date: "10/04/2025",
                  replies: 15,
                  excerpt: "Gostaria de discutir as diferenças fundamentais entre o monismo de Spinoza e o dualismo cartesiano. Como essas visões influenciam suas respectivas teorias sobre mente e corpo?"
                },
                {
                  id: 2,
                  title: "O conceito de conatus e sua relevância contemporânea",
                  author: "Maria Oliveira",
                  date: "08/04/2025",
                  replies: 7,
                  excerpt: "O conceito de conatus (esforço para perseverar no ser) pode ser aplicado a questões contemporâneas? Quais seriam as implicações para a psicologia ou ecologia?"
                },
                {
                  id: 3,
                  title: "Spinoza e o determinismo: somos realmente livres?",
                  author: "João Pereira",
                  date: "05/04/2025",
                  replies: 23,
                  excerpt: "Spinoza defende um determinismo rigoroso, mas também fala de liberdade. Como conciliar essas ideias? O que significa ser livre na perspectiva spinozista?"
                }
              ].map((discussion) => (
                <Card key={discussion.id} className="border border-muted">
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-lg">{discussion.title}</CardTitle>
                      <span className="text-sm text-muted-foreground">{discussion.replies} respostas</span>
                    </div>
                    <CardDescription>
                      Por {discussion.author} • {discussion.date}
                    </CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-muted-foreground">{discussion.excerpt}</p>
                  </CardContent>
                  <CardFooter>
                    <Button asChild variant="outline" className="w-full">
                      <Link href={`/atividades-interativas/forum/spinoza/${discussion.id}`}>
                        Ver Discussão Completa
                      </Link>
                    </Button>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        </CardContent>
        <CardFooter className="flex justify-center">
          <Button variant="outline">Ver Mais Discussões</Button>
        </CardFooter>
      </Card>
    </div>
  );
}
