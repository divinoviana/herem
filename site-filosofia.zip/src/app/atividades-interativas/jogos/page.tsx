import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";

export default function JogosFilosoficosPage() {
  return (
    <MainLayout>
      <section className="filosofia-hero bg-secondary">
        <div className="absolute inset-0 bg-gradient-to-r from-secondary/80 to-accent/80 opacity-90"></div>
        <div className="container relative z-10 mx-auto px-4 py-16 text-center">
          <h1 className="mb-6 text-4xl font-bold md:text-5xl lg:text-6xl">
            Jogos Filosóficos
          </h1>
          <p className="mx-auto mb-8 max-w-3xl text-lg md:text-xl">
            Aprenda filosofia de forma divertida e interativa com nossos jogos filosóficos.
            Desafie seu pensamento, teste seus conhecimentos e explore conceitos filosóficos através de experiências lúdicas.
          </p>
        </div>
      </section>

      <section className="filosofia-section">
        <div className="filosofia-container">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Dilema do Prisioneiro</CardTitle>
                <CardDescription>Jogo de estratégia baseado em teoria dos jogos</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Explore o famoso dilema ético através de um jogo interativo. Faça escolhas e veja as consequências de cooperar ou trair em diferentes cenários.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full filosofia-button-secondary">
                  <Link href="/atividades-interativas/jogos/dilema-prisioneiro">
                    Jogar Agora
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Quem é o Filósofo?</CardTitle>
                <CardDescription>Jogo de adivinhação filosófica</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Tente adivinhar qual filósofo está sendo descrito com base em pistas sobre sua vida, obra e pensamento. Quanto menos pistas precisar, mais pontos ganha!
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full filosofia-button-secondary">
                  <Link href="/atividades-interativas/jogos/quem-e-o-filosofo">
                    Jogar Agora
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Construtor de Argumentos</CardTitle>
                <CardDescription>Jogo de lógica e argumentação</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Construa argumentos válidos combinando premissas e conclusões. Aprenda sobre lógica formal e falácias enquanto tenta criar os argumentos mais sólidos.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full filosofia-button-secondary">
                  <Link href="/atividades-interativas/jogos/construtor-argumentos">
                    Jogar Agora
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Simulador de Alegoria da Caverna</CardTitle>
                <CardDescription>Experiência interativa baseada em Platão</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Vivencie a famosa alegoria da caverna de Platão nesta experiência interativa. Explore os diferentes níveis de realidade e conhecimento.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full filosofia-button-secondary">
                  <Link href="/atividades-interativas/jogos/alegoria-caverna">
                    Jogar Agora
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Trilha Ética</CardTitle>
                <CardDescription>Jogo de tabuleiro virtual sobre dilemas éticos</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Avance no tabuleiro respondendo a dilemas éticos. Suas escolhas determinarão seu caminho e o resultado final do jogo.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full filosofia-button-secondary">
                  <Link href="/atividades-interativas/jogos/trilha-etica">
                    Jogar Agora
                  </Link>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Modo de Spinoza</CardTitle>
                <CardDescription>Jogo de simulação baseado na filosofia de Spinoza</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Experimente o mundo através da perspectiva spinozista. Compreenda os conceitos de substância, atributos e modos enquanto navega por diferentes cenários.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full filosofia-button-secondary">
                  <Link href="/atividades-interativas/jogos/modo-spinoza">
                    Jogar Agora
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>

      <section className="filosofia-section bg-muted/30">
        <div className="filosofia-container">
          <h2 className="filosofia-heading text-center">Destaque: Modo de Spinoza</h2>
          <p className="mx-auto mb-12 max-w-3xl text-center text-muted-foreground">
            Explore o pensamento de Baruch Spinoza através deste jogo interativo que simula sua visão filosófica do mundo.
          </p>
          
          <div className="mx-auto max-w-4xl">
            <Card className="filosofia-card">
              <div className="h-64 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Modo de Spinoza: Uma Experiência Filosófica</CardTitle>
                <CardDescription>
                  Desenvolvido especialmente para o Portal de Filosofia
                </CardDescription>
              </CardHeader>
              <CardContent>
                <p className="mb-4">
                  Neste jogo interativo, você experimentará o mundo através da perspectiva filosófica de Baruch Spinoza. 
                  Como um "modo" da substância infinita, você navegará por diferentes cenários que ilustram conceitos fundamentais do pensamento spinozista:
                </p>
                <ul className="list-disc pl-5 space-y-2 text-muted-foreground">
                  <li>Compreenda a relação entre a substância única (Deus/Natureza) e seus modos finitos</li>
                  <li>Explore os atributos do pensamento e da extensão</li>
                  <li>Experimente o determinismo e a liberdade na visão de Spinoza</li>
                  <li>Desenvolva seu conatus (esforço para perseverar no ser)</li>
                  <li>Transforme paixões passivas em afetos ativos</li>
                  <li>Busque o conhecimento intuitivo e o amor intelectual a Deus</li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <Link href="/atividades-interativas/jogos/modo-spinoza">
                    Iniciar Experiência
                  </Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
