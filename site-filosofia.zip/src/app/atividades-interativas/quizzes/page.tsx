"use client";

import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useState } from "react";

export default function QuizPage() {
  return (
    <MainLayout>
      <section className="filosofia-hero bg-secondary">
        <div className="absolute inset-0 bg-gradient-to-r from-secondary/80 to-accent/80 opacity-90"></div>
        <div className="container relative z-10 mx-auto px-4 py-16 text-center">
          <h1 className="mb-6 text-4xl font-bold md:text-5xl lg:text-6xl">
            Quizzes Filosóficos
          </h1>
          <p className="mx-auto mb-8 max-w-3xl text-lg md:text-xl">
            Teste seus conhecimentos sobre filosofia com nossos quizzes interativos.
          </p>
        </div>
      </section>

      <section className="filosofia-section">
        <div className="filosofia-container">
          <h2 className="filosofia-heading text-center">Quizzes Disponíveis</h2>
          <p className="mx-auto mb-12 max-w-3xl text-center text-muted-foreground">
            Escolha um dos quizzes abaixo para testar seus conhecimentos filosóficos.
          </p>
          
          <div className="grid grid-cols-1 gap-8 md:grid-cols-2 lg:grid-cols-3">
            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Filosofia Antiga</CardTitle>
                <CardDescription>Dos pré-socráticos ao helenismo</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Teste seus conhecimentos sobre os filósofos da Grécia Antiga, incluindo Sócrates, Platão e Aristóteles.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <a href="/atividades-interativas/quizzes/filosofia-antiga">
                    Iniciar Quiz
                  </a>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Filosofia Medieval</CardTitle>
                <CardDescription>Fé e razão na Idade Média</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Desafie-se com perguntas sobre os principais pensadores medievais, como Agostinho, Tomás de Aquino e Ockham.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <a href="/atividades-interativas/quizzes/filosofia-medieval">
                    Iniciar Quiz
                  </a>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Filosofia Moderna</CardTitle>
                <CardDescription>Racionalismo, empirismo e iluminismo</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Teste seus conhecimentos sobre os filósofos modernos, incluindo Descartes, Spinoza, Locke, Hume e Kant.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <a href="/atividades-interativas/quizzes/filosofia-moderna">
                    Iniciar Quiz
                  </a>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Filosofia Contemporânea</CardTitle>
                <CardDescription>Correntes filosóficas atuais</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Desafie-se com perguntas sobre as correntes filosóficas dos séculos XIX, XX e XXI, como existencialismo, fenomenologia e filosofia analítica.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <a href="/atividades-interativas/quizzes/filosofia-contemporanea">
                    Iniciar Quiz
                  </a>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Ética e Política</CardTitle>
                <CardDescription>Reflexões sobre moral e sociedade</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Teste seus conhecimentos sobre teorias éticas e políticas, desde a antiguidade até os debates contemporâneos.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <a href="/atividades-interativas/quizzes/etica-politica">
                    Iniciar Quiz
                  </a>
                </Button>
              </CardFooter>
            </Card>

            <Card className="filosofia-card highlight-card">
              <div className="h-48 w-full bg-muted"></div>
              <CardHeader>
                <CardTitle>Spinoza</CardTitle>
                <CardDescription>O filósofo da imanência</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Quiz especial sobre Baruch Spinoza, sua vida, obra e principais conceitos filosóficos.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full">
                  <a href="/atividades-interativas/quizzes/spinoza">
                    Iniciar Quiz
                  </a>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>

      <section className="filosofia-section bg-muted/30">
        <div className="filosofia-container">
          <h2 className="filosofia-heading text-center">Quiz Demonstrativo</h2>
          <p className="mx-auto mb-12 max-w-3xl text-center text-muted-foreground">
            Experimente este mini-quiz sobre conceitos básicos de filosofia.
          </p>
          
          <div className="mx-auto max-w-2xl">
            <Card className="filosofia-card">
              <CardHeader>
                <CardTitle>Mini-Quiz: Conceitos Básicos</CardTitle>
                <CardDescription>
                  Teste seus conhecimentos com estas 3 perguntas
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-8">
                  <div>
                    <h3 className="mb-4 text-lg font-medium">1. O que significa a palavra "filosofia"?</h3>
                    <RadioGroup defaultValue="option1">
                      <div className="flex items-start space-x-2">
                        <RadioGroupItem value="option1" id="option1" />
                        <Label className="flex flex-col" htmlFor="option1">
                          <span>Amor à sabedoria</span>
                          <span className="text-sm text-muted-foreground">Do grego "philo" (amor) e "sophia" (sabedoria)</span>
                        </Label>
                      </div>
                      <div className="flex items-start space-x-2">
                        <RadioGroupItem value="option2" id="option2" />
                        <Label className="flex flex-col" htmlFor="option2">
                          <span>Estudo da natureza</span>
                          <span className="text-sm text-muted-foreground">Do grego "physis" (natureza) e "logos" (estudo)</span>
                        </Label>
                      </div>
                      <div className="flex items-start space-x-2">
                        <RadioGroupItem value="option3" id="option3" />
                        <Label className="flex flex-col" htmlFor="option3">
                          <span>Conhecimento divino</span>
                          <span className="text-sm text-muted-foreground">Do grego "theos" (deus) e "sophia" (sabedoria)</span>
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>
                  
                  <div>
                    <h3 className="mb-4 text-lg font-medium">2. Quem é considerado o pai da filosofia ocidental?</h3>
                    <RadioGroup defaultValue="option1">
                      <div className="flex items-start space-x-2">
                        <RadioGroupItem value="option1" id="option4" />
                        <Label className="flex flex-col" htmlFor="option4">
                          <span>Tales de Mileto</span>
                          <span className="text-sm text-muted-foreground">Primeiro filósofo a buscar explicações naturais para fenômenos</span>
                        </Label>
                      </div>
                      <div className="flex items-start space-x-2">
                        <RadioGroupItem value="option2" id="option5" />
                        <Label className="flex flex-col" htmlFor="option5">
                          <span>Sócrates</span>
                          <span className="text-sm text-muted-foreground">Conhecido por seu método de questionamento</span>
                        </Label>
                      </div>
                      <div className="flex items-start space-x-2">
                        <RadioGroupItem value="option3" id="option6" />
                        <Label className="flex flex-col" htmlFor="option6">
                          <span>Platão</span>
                          <span className="text-sm text-muted-foreground">Fundador da Academia e autor dos Diálogos</span>
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>
                  
                  <div>
                    <h3 className="mb-4 text-lg font-medium">3. Qual destas é uma obra de Spinoza?</h3>
                    <RadioGroup defaultValue="option1">
                      <div className="flex items-start space-x-2">
                        <RadioGroupItem value="option1" id="option7" />
                        <Label className="flex flex-col" htmlFor="option7">
                          <span>Ética</span>
                          <span className="text-sm text-muted-foreground">Escrita segundo o método geométrico</span>
                        </Label>
                      </div>
                      <div className="flex items-start space-x-2">
                        <RadioGroupItem value="option2" id="option8" />
                        <Label className="flex flex-col" htmlFor="option8">
                          <span>Crítica da Razão Pura</span>
                          <span className="text-sm text-muted-foreground">Investigação sobre os limites do conhecimento</span>
                        </Label>
                      </div>
                      <div className="flex items-start space-x-2">
                        <RadioGroupItem value="option3" id="option9" />
                        <Label className="flex flex-col" htmlFor="option9">
                          <span>O Mundo como Vontade e Representação</span>
                          <span className="text-sm text-muted-foreground">Obra sobre metafísica e estética</span>
                        </Label>
                      </div>
                    </RadioGroup>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button className="w-full">Verificar Respostas</Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
