import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { ScrollArea } from "@/components/ui/scroll-area";
import Link from "next/link";

export default function ChatPage() {
  return (
    <MainLayout>
      <section className="filosofia-hero bg-accent">
        <div className="absolute inset-0 bg-gradient-to-r from-accent/80 to-primary/80 opacity-90"></div>
        <div className="container relative z-10 mx-auto px-4 py-16 text-center">
          <h1 className="mb-6 text-4xl font-bold md:text-5xl lg:text-6xl">
            Chat Filosófico
          </h1>
          <p className="mx-auto mb-8 max-w-3xl text-lg md:text-xl">
            Converse em tempo real com outros estudantes e professores sobre temas filosóficos.
            Tire dúvidas, compartilhe ideias e aprofunde seu conhecimento através do diálogo.
          </p>
        </div>
      </section>

      <section className="filosofia-section">
        <div className="filosofia-container">
          <div className="grid grid-cols-1 gap-8 md:grid-cols-4">
            {/* Sidebar com salas de chat */}
            <div className="md:col-span-1">
              <Card className="filosofia-card">
                <CardHeader>
                  <CardTitle>Salas de Chat</CardTitle>
                  <CardDescription>Escolha uma sala para conversar</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {[
                      { id: 1, name: "Spinoza e o Monismo", active: true, users: 12 },
                      { id: 2, name: "Ética e Moral", active: false, users: 8 },
                      { id: 3, name: "Filosofia Antiga", active: false, users: 5 },
                      { id: 4, name: "Filosofia Contemporânea", active: false, users: 3 },
                      { id: 5, name: "Filosofia Brasileira", active: false, users: 2 },
                      { id: 6, name: "Ajuda com Trabalhos", active: false, users: 15 }
                    ].map((room) => (
                      <div 
                        key={room.id} 
                        className={`flex items-center justify-between rounded-md p-2 ${
                          room.active 
                            ? "bg-primary text-primary-foreground" 
                            : "hover:bg-muted/50 cursor-pointer"
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <div className={`h-2 w-2 rounded-full ${room.active ? "bg-green-400" : "bg-muted-foreground"}`}></div>
                          <span>{room.name}</span>
                        </div>
                        <span className="text-xs">{room.users} online</span>
                      </div>
                    ))}
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full">
                    Criar Nova Sala
                  </Button>
                </CardFooter>
              </Card>
            </div>

            {/* Chat principal */}
            <div className="md:col-span-3">
              <Card className="filosofia-card">
                <CardHeader className="border-b">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div className="h-2 w-2 rounded-full bg-green-400"></div>
                      <CardTitle>Spinoza e o Monismo</CardTitle>
                    </div>
                    <span className="text-sm text-muted-foreground">12 usuários online</span>
                  </div>
                </CardHeader>
                <CardContent className="p-0">
                  <ScrollArea className="h-[500px] p-4">
                    <div className="space-y-4">
                      {[
                        {
                          id: 1,
                          user: "Prof. Silva",
                          avatar: "S",
                          message: "Bem-vindos à sala de discussão sobre Spinoza e o Monismo! Alguém poderia explicar brevemente o que entende por monismo na filosofia de Spinoza?",
                          time: "14:30",
                          isCurrentUser: false
                        },
                        {
                          id: 2,
                          user: "Maria Oliveira",
                          avatar: "M",
                          message: "Pelo que entendi, o monismo de Spinoza é a ideia de que existe apenas uma substância no universo, que ele identifica como Deus ou Natureza. Diferente do dualismo cartesiano que separa mente e matéria como substâncias distintas.",
                          time: "14:32",
                          isCurrentUser: false
                        },
                        {
                          id: 3,
                          user: "João Pereira",
                          avatar: "J",
                          message: "Exatamente, Maria! E essa substância única tem infinitos atributos, dos quais conhecemos apenas dois: pensamento e extensão.",
                          time: "14:35",
                          isCurrentUser: false
                        },
                        {
                          id: 4,
                          user: "Ana Santos",
                          avatar: "A",
                          message: "Tenho uma dúvida: se Deus e Natureza são a mesma coisa para Spinoza, isso significa que ele era ateu? Ou ele redefine o conceito de Deus?",
                          time: "14:38",
                          isCurrentUser: false
                        },
                        {
                          id: 5,
                          user: "Prof. Silva",
                          avatar: "S",
                          message: "Ótima pergunta, Ana! Spinoza não era ateu, mas sua concepção de Deus é muito diferente da visão teísta tradicional. Para ele, Deus não é um ser transcendente e pessoal, mas imanente e impessoal - a própria ordem natural do universo.",
                          time: "14:40",
                          isCurrentUser: false
                        },
                        {
                          id: 6,
                          user: "Carlos Mendes",
                          avatar: "C",
                          message: "Por isso ele foi excomungado da comunidade judaica, certo? Suas ideias eram consideradas heréticas na época.",
                          time: "14:42",
                          isCurrentUser: false
                        },
                        {
                          id: 7,
                          user: "Você",
                          avatar: "V",
                          message: "Sim, e além disso, Spinoza rejeitava a ideia de que Deus age com propósitos ou finalidades. Para ele, tudo o que acontece é necessário e determinado pela natureza de Deus/Substância.",
                          time: "14:45",
                          isCurrentUser: true
                        }
                      ].map((message) => (
                        <div 
                          key={message.id} 
                          className={`flex ${message.isCurrentUser ? "justify-end" : "justify-start"}`}
                        >
                          <div className={`max-w-[80%] rounded-lg p-3 ${
                            message.isCurrentUser 
                              ? "bg-primary text-primary-foreground" 
                              : "bg-muted"
                          }`}>
                            <div className="mb-1 flex items-center gap-2">
                              <Avatar className="h-6 w-6">
                                <AvatarFallback>{message.avatar}</AvatarFallback>
                              </Avatar>
                              <span className="text-sm font-medium">{message.user}</span>
                              <span className="text-xs opacity-70">{message.time}</span>
                            </div>
                            <p>{message.message}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </CardContent>
                <CardFooter className="border-t p-4">
                  <div className="flex w-full items-center gap-2">
                    <Input 
                      placeholder="Digite sua mensagem..." 
                      className="flex-1"
                    />
                    <Button>Enviar</Button>
                  </div>
                </CardFooter>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </MainLayout>
  );
}
