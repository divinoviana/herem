import { MainLayout } from "@/components/layout/main-layout";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import Link from "next/link";

export default function Home() {
  return (
    <MainLayout>
      {/* Hero Section */}
      <section className="filosofia-hero">
        <div className="absolute inset-0 bg-[url('/images/hero-bg.jpg')] bg-cover bg-center opacity-20"></div>
        <div className="container relative z-10 mx-auto px-4 py-24 text-center">
          <h1 className="mb-6 text-4xl font-bold md:text-5xl lg:text-6xl">
            Portal de Filosofia
          </h1>
          <p className="mx-auto mb-8 max-w-3xl text-lg md:text-xl">
            Um espaço dedicado à reflexão filosófica para estudantes do ensino médio.
            Explore o pensamento dos grandes filósofos e desenvolva seu próprio olhar crítico sobre o mundo.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button asChild size="lg" className="filosofia-button-accent">
              <Link href="/areas-tematicas">Explorar Áreas Temáticas</Link>
            </Button>
            <Button asChild variant="outline" size="lg">
              <Link href="/recursos-didaticos">Ver Recursos Didáticos</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* Áreas Temáticas Section */}
      <section className="filosofia-section bg-muted/30">
        <div className="filosofia-container">
          <h2 className="filosofia-heading text-center">Áreas Temáticas</h2>
          <p className="mx-auto mb-12 max-w-3xl text-center text-muted-foreground">
            Explore os principais campos da filosofia e conheça as ideias que moldaram o pensamento humano ao longo da história.
          </p>
          <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {[
              {
                title: "Filosofia Antiga",
                description: "Dos pré-socráticos ao helenismo",
                link: "/areas-tematicas/filosofia-antiga",
              },
              {
                title: "Filosofia Medieval",
                description: "Fé e razão na Idade Média",
                link: "/areas-tematicas/filosofia-medieval",
              },
              {
                title: "Filosofia Moderna",
                description: "Racionalismo, empirismo e iluminismo",
                link: "/areas-tematicas/filosofia-moderna",
              },
              {
                title: "Filosofia Contemporânea",
                description: "Correntes filosóficas atuais",
                link: "/areas-tematicas/filosofia-contemporanea",
              },
              {
                title: "Filosofia Brasileira",
                description: "O pensamento filosófico no Brasil",
                link: "/areas-tematicas/filosofia-brasileira",
              },
              {
                title: "Ética e Política",
                description: "Reflexões sobre moral e sociedade",
                link: "/areas-tematicas/etica-politica",
              },
              {
                title: "Lógica e Conhecimento",
                description: "Fundamentos do raciocínio e da epistemologia",
                link: "/areas-tematicas/logica-conhecimento",
              },
              {
                title: "Estética e Arte",
                description: "Filosofia da beleza e da criação artística",
                link: "/areas-tematicas/estetica-arte",
              },
            ].map((area, index) => (
              <Card key={index} className="filosofia-card">
                <CardHeader>
                  <CardTitle>{area.title}</CardTitle>
                  <CardDescription>{area.description}</CardDescription>
                </CardHeader>
                <CardFooter>
                  <Button asChild variant="outline" className="w-full">
                    <Link href={area.link}>Explorar</Link>
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Recursos Didáticos Section */}
      <section className="filosofia-section">
        <div className="filosofia-container">
          <h2 className="filosofia-heading text-center">Recursos Didáticos</h2>
          <p className="mx-auto mb-12 max-w-3xl text-center text-muted-foreground">
            Materiais de apoio para enriquecer seus estudos e aprofundar seus conhecimentos filosóficos.
          </p>
          <div className="grid grid-cols-1 gap-6 md:grid-cols-3">
            <Card className="filosofia-card">
              <CardHeader>
                <CardTitle>Textos e Artigos</CardTitle>
                <CardDescription>Leituras selecionadas para aprofundamento</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 text-muted-foreground">
                  <li>Textos clássicos adaptados</li>
                  <li>Artigos introdutórios</li>
                  <li>Análises de obras filosóficas</li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button asChild variant="outline" className="w-full">
                  <Link href="/recursos-didaticos#textos">Acessar</Link>
                </Button>
              </CardFooter>
            </Card>
            <Card className="filosofia-card">
              <CardHeader>
                <CardTitle>Multimídia</CardTitle>
                <CardDescription>Conteúdos audiovisuais sobre filosofia</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 text-muted-foreground">
                  <li>Vídeos explicativos</li>
                  <li>Podcasts filosóficos</li>
                  <li>Infográficos e mapas conceituais</li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button asChild variant="outline" className="w-full">
                  <Link href="/recursos-didaticos#multimidia">Acessar</Link>
                </Button>
              </CardFooter>
            </Card>
            <Card className="filosofia-card">
              <CardHeader>
                <CardTitle>Material de Estudo</CardTitle>
                <CardDescription>Recursos para aprendizado estruturado</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="list-disc pl-5 text-muted-foreground">
                  <li>Guias de estudo</li>
                  <li>Glossário filosófico</li>
                  <li>Linha do tempo do pensamento</li>
                </ul>
              </CardContent>
              <CardFooter>
                <Button asChild variant="outline" className="w-full">
                  <Link href="/recursos-didaticos#material">Acessar</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>

      {/* Atividades Interativas Section */}
      <section className="filosofia-section bg-secondary/10">
        <div className="filosofia-container">
          <h2 className="filosofia-heading text-center">Atividades Interativas</h2>
          <p className="mx-auto mb-12 max-w-3xl text-center text-muted-foreground">
            Exercite seu pensamento filosófico com nossas atividades interativas e desafios.
          </p>
          <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
            <Card className="filosofia-card">
              <CardHeader>
                <CardTitle>Quizzes Filosóficos</CardTitle>
                <CardDescription>Teste seus conhecimentos</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Desafie-se com perguntas sobre os principais conceitos, pensadores e correntes filosóficas.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full filosofia-button-secondary">
                  <Link href="/atividades-interativas/quizzes">Iniciar Quiz</Link>
                </Button>
              </CardFooter>
            </Card>
            <Card className="filosofia-card">
              <CardHeader>
                <CardTitle>Debates Filosóficos</CardTitle>
                <CardDescription>Participe de discussões</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">
                  Explore temas filosóficos contemporâneos através de debates estruturados e troca de ideias.
                </p>
              </CardContent>
              <CardFooter>
                <Button asChild className="w-full filosofia-button-secondary">
                  <Link href="/atividades-interativas/debates">Participar</Link>
                </Button>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="filosofia-section bg-primary text-primary-foreground">
        <div className="filosofia-container text-center">
          <h2 className="mb-6 text-3xl font-bold md:text-4xl">Comece sua jornada filosófica</h2>
          <p className="mx-auto mb-8 max-w-2xl">
            A filosofia nos ajuda a desenvolver o pensamento crítico e a compreender melhor o mundo ao nosso redor.
            Explore nosso portal e descubra o fascinante universo das ideias filosóficas.
          </p>
          <Button asChild size="lg" variant="secondary">
            <Link href="/areas-tematicas">Explorar Agora</Link>
          </Button>
        </div>
      </section>
    </MainLayout>
  );
}
